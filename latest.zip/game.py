# main.py
import math
import pygame as pg
import time
import pymunk as pm
okafrom level import Level
import character as ch
from pygame.locals import *
import os
import sys
# import msal # Not used in the provided snippet
# import requests # Not used in the provided snippet
# import zipfile # Not used in the provided snippet
# import shutil # Not used in the provided snippet
# import json # Not used in the provided snippet
from pymunk import Vec2d
import random
from Polygon import Static_line, Polygon 
from utils import load_resource

# GLOBALS
bird = None
bird_img = None

# Buoyancy and Water Physics Constants
WATER_SURFACE_Y_DEFAULT = 130.0 # Default Y coordinate of the water/ground surface (Pymunk world units)
BUOYANCY_FACTOR = 7.0          # Net upward acceleration factor

# --- Old Damping Constants (will be superseded by momentum-based logic below for objects in water) ---
# WATER_LINEAR_DAMPING = 0.98
# WATER_ANGULAR_DAMPING = 0.98

# --- Momentum-Based Damping Constants ---
MOMENTUM_LOW_THRESHOLD = 200.0    # Momentum below this gets stronger damping
MOMENTUM_HIGH_THRESHOLD = 3000.0  # Momentum above this gets weaker damping

# Damping factor: 1.0 = no damping, < 1.0 = damping occurs.
# Closer to 1.0 means LESS damping. Further from 1.0 means MORE damping.
DAMPING_LINEAR_LOW_MOMENTUM = 0.50  # More linear drag for low momentum objects
DAMPING_LINEAR_HIGH_MOMENTUM = 0.99 # Less linear drag for high momentum objects

DAMPING_ANGULAR_LOW_MOMENTUM = 0.50 # More angular drag for low momentum objects
DAMPING_ANGULAR_HIGH_MOMENTUM = 0.99 # Less angular drag for high momentum objects

# Helper function for momentum-based damping
def get_momentum_based_damping_factor(momentum, low_thresh, high_thresh, low_damp_factor, high_damp_factor):
    if momentum <= low_thresh:
        return low_damp_factor
    if momentum >= high_thresh:
        return high_damp_factor
    
    # Interpolate for momentum between thresholds
    momentum_range = high_thresh - low_thresh
    # Avoid division by zero if thresholds are the same (should not happen with good constants)
    if momentum_range == 0: 
        return high_damp_factor 
    
    damping_factor_range = high_damp_factor - low_damp_factor
    normalized_momentum = (momentum - low_thresh) / momentum_range
    return low_damp_factor + normalized_momentum * damping_factor_range

sling_anchor = (130, 380)
x_mouse,y_mouse = 0,0
pigs = []
birds = []
balls = []
polys = []
beams = []
columns = []
circles = []
triangles = []
poly_points = []
ball_num = 0
polys_dict = {}
mouse_distance = 0
rope_length = 90
angle = 90
launch_angle = 0
pu = 0
levels_drawn = False
ssahur = None

sound_on = True
count = 0
mouse_pressed_to_shoot = False
tick_to_next_circle = 10

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)
PINK = (255, 192, 203)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
TRANSP = (0, 0, 0, 0)



score = 0
settings_open = False

game_state = 7
levels_drawn = False
bird_path = []
counter = 0
restart_counter = False
bonus_score_once = True

last_resume_time = 0.0 # Time when the game was last resumed
game_just_resumed = False
loaded = False

# Patapim's slowdown effect variables
patapim_slowdown_active = False
patapim_slowdown_start_time = 0.0
patapim_slowdown_duration = 2.0  # Duration of slowdown in seconds
current_slowdown_factor = 1.0    # Normally 1.0, < 1.0 for slowdown
# Patapim aiming variables
patapim_is_aiming_potion = False
patapim_aim_trajectory_points = []

wall = False

# Add at the top with other globals
slingl = None
slingr = None
slingl_scaled_width = None
slingl_scaled_height = None
slingr_scaled_width = None
slingr_scaled_height = None

# Module-level (global) screen variables
screen = None
screen_width = 1200 # Default base width
screen_height = 650 # Default base height
scale_x = 1.0
scale_y = 1.0
base_width, base_height = 1200, 650 # Keep base dimensions for scaling logic

# Level Menu Pagination Globals
MAX_LEVELS = 42
LEVELS_PER_PAGE = 21 # 3 rows of 7 icons
current_level_page = 0

# Resume delay variables
is_resuming = False
resuming_initiated_time = 0.0
RESUME_DELAY = 0.3  # Seconds 

# Initialize active_explosions as a global sprite group - Moved from original position
# Initialize active_explosions as a global sprite group
active_explosions = pg.sprite.Group()
bird_exit_sound = None



POLY_POLY_COLLISION_IMPULSE_THRESHOLD = 500.0 
POLY_POLY_DAMAGE_VALUE = 50  # Increased from 15
POLY_DESTROY_SCORE = 500    
PIG_KO_SCORE = 10000         # Score for knocking out a pig
ABILITY_COLLISION_IMPULSE_THRESHOLD = 2000.0 
POLY_GROUND_IMPULSE_THRESHOLD = 750.0 # For polygons hitting the ground
POLY_GROUND_DAMAGE_FACTOR = 0.1      # Damage factor for polygons hitting ground

BOMB_EXPLOSION_KNOCKBACK_BASE = 7500 # Base impulse for bomb knockback
# Patapim's Potion Explosion Parameters
POTION_EXPLOSION_RADIUS = 110
POTION_EXPLOSION_DAMAGE_PIGS = 160
POTION_EXPLOSION_DAMAGE_POLYS = 1300
POTION_EXPLOSION_KNOCKBACK_BASE = 7000

# Potion Pig Growth Effect Parameters
POTION_EFFECT_RADIUS = 220      # World units for the effect radius
POTION_PIG_GROWTH_DURATION = 1 # Seconds for pigs to reach full new size
POTION_PIG_GROWTH_SCALE_MULTIPLIER = 5 # Pigs will become 5x their original size
growing_pigs_effects = {} # Tracks growing pigs: {pig_instance: {"start_time": float, "original_radius": float, "original_mass": float}}

# Explosion Visual Constants (Corrected paths to include "resources")
BOMB_EXPLOSION_FRAME_FOLDER = "./resources/images/explosion_frames/"
BOMB_EXPLOSION_FRAME_DURATION_MS = 50
BOMB_EXPLOSION_SCALE_PX = (250, 250) # Increased visual size
BOMB_PROJECTILE_EXPLOSION_RADIUS = 180 # New constant for Bomb projectile's effect radius

PALOCLEVES_EXPLOSION_FRAME_FOLDER = "./resources/images/explosion_frames/" # Assumes same animation as Bomb for now
PALOCLEVES_EXPLOSION_FRAME_DURATION_MS = 60
PALOCLEVES_EXPLOSION_SCALE_PX = (300, 300) # Increased visual size

# Impact Visual Constants (for non-explosive hits)
IMPACT_FRAME_FOLDER = "./resources/images/collision_frames/"
IMPACT_FRAME_DURATION_MS = 40 # Adjust as needed
IMPACT_SCALE_PX = (75, 75)   # Adjust as needed
MIN_IMPULSE_FOR_IMPACT_VISUAL = 150 # Lowered: Minimum collision impulse to show an impact visual

# Splash Visual Constants
SPLASH_FRAME_FOLDER = "./resources/images/water_frames/"
SPLASH_FRAME_DURATION_MS = 50 # Adjust as needed
SPLASH_SCALE_PX = (100, 100) # Adjust as needed
SPLASH_SOUND_COOLDOWN = 1.0  # Increased: Seconds between splash sounds for the same object


def main_loop():
    
    # GLOBALS
    global POLY_DESTROY_SCORE
    # Ensure active_explosions is declared global if it's modified directly (e.g., reassigned)
    # or for clarity if its methods are frequently called.
    global POLY_POLY_COLLISION_IMPULSE_THRESHOLD
    global POLY_POLY_DAMAGE_VALUE
    global ABILITY_COLLISION_IMPULSE_THRESHOLD
    global POLY_GROUND_IMPULSE_THRESHOLD
    global POLY_GROUND_DAMAGE_FACTOR
    global BOMB_EXPLOSION_KNOCKBACK_BASE
    global POTION_EXPLOSION_RADIUS
    global POTION_EXPLOSION_DAMAGE_PIGS
    global POTION_EXPLOSION_DAMAGE_POLYS
    global POTION_EXPLOSION_KNOCKBACK_BASE
    global POTION_EFFECT_RADIUS
    global POTION_PIG_GROWTH_DURATION
    global POTION_PIG_GROWTH_SCALE_MULTIPLIER
    global growing_pigs_effects
    # Declare screen-related variables as global if they are to be modified
    # by nested functions like handle_resize and accessed globally.
    global screen, screen_width, screen_height, scale_x, scale_y 
    global base_width, base_height # Ensure base_width/height are accessible if needed globally or by handle_resize


    # This was the previous placement, let's ensure it's with the other game-state globals
    # global active_explosions 


    global bird_img
    global bird
    global sling_anchor
    global x_mouse
    global y_mouse
    global pigs
    global birds
    global balls
    global polys
    global beams
    global columns
    global circles
    global triangles
    global poly_points
    global ball_num
    global polys_dict
    global mouse_distance
    global rope_length
    global angle
    global launch_angle
    global pu
    global slingl, slingr, slingl_scaled_width, slingl_scaled_height, slingr_scaled_width, slingr_scaled_height
    global ssahur

    global sound_on
    global count
    global mouse_pressed_to_shoot
    global tick_to_next_circle
    global loaded
    global settings_open

    global RED
    global BLUE
    global YELLOW
    global ORANGE
    global PURPLE
    global PINK
    global BLACK
    global WHITE
    global TRANSP

    global slingl_x
    global slingl_y
    global slingr_x
    global slingr_y # Kept as it's assigned in sling_action, though primarily used locally. Better to pass if needed.
    global score
    global game_state
    global levels_drawn
    global bird_path
    global counter
    global restart_counter
    global bonus_score_once
    global levels_drawn
    global last_resume_time
    global game_just_resumed 
    # Removed global patapim_instance_in_slowmo as it's not defined or used
    global patapim_slowdown_active
    global patapim_slowdown_start_time
    global patapim_slowdown_duration
    global current_slowdown_factor # Patapim's slowdown effect variables
    global current_level_page # For level menu pagination
    global patapim_is_aiming_potion
    global patapim_aim_trajectory_points
    global is_resuming # Added for resume delay
    global resuming_initiated_time # Added for resume delay
    global active_explosions # Declare active_explosions as global here
    global bird_ability_explosion_sounds_list # Add new sound list to globals
    global bird_exit_sound # Add bird_exit_sound to globals
    global stop_button_is_hovered, stop_button_is_pressed # Add button state globals
    global stop_button_original, stop_button_darkened # Add button image globals
    global wood_break_sounds_list, stone_break_sounds_list, glass_break_sounds_list # Add material break sound lists


    
    global terrain_texture, water_texture # Declare terrain_texture and water_texture as global

    global wall



    
    pg.init()
    pg.mixer.init()
    # Example
    # launch_sound = pg.mixer.Sound("path/to/launch_sound.wav")
    # collision_sound = pg.mixer.Sound("path/to/collision_sound.ogg")
    
    # Load background music
    pg.mixer.music.load(load_resource("./resources/sounds/bg_music.mp3"))
    pg.mixer.music.set_volume(0.4) # Adjust volume as needed (0.0 to 1.0)

    # Ensure level 1 is always unlocked
    cleared_levels_file = "cleared_levels.txt"
    try:
        if not os.path.exists(load_resource(cleared_levels_file)):
            with open(load_resource(cleared_levels_file), "w") as f:
                f.write("1\n")
        else:
            is_empty = True
            with open(load_resource(cleared_levels_file), "r") as f:
                for line in f:
                    if line.strip():
                        is_empty = False
                        break
            if is_empty:
                with open(load_resource(cleared_levels_file), "w") as f:
                    f.write("1\n")
    except Exception as e: # Catching specific exception is better if possible
        print(f"Error initializing {cleared_levels_file}: {e}")

    # screen_width, screen_height = 1200, 650 # Now global, initialized at module level
    # Set to fullscreen mode. (0,0) tells Pygame to use the current desktop resolution.
    screen = pg.display.set_mode((0, 0), pg.FULLSCREEN) # Assigns to global screen
    screen_width, screen_height = pg.display.get_surface().get_size()
    base_width, base_height = 1200, 650
    scale_x = screen_width / base_width
    scale_y = screen_height / base_height
    
    

    def scale_pos(x, y):
        return x * scale_x, y * scale_y

    def scale_size(width, height):
        return width * scale_x, height * scale_y
    
    #sling_anchor = scale_pos(130, 380)
    
    # Base positions for sling
    # These seem to be used for drawing the sling parts, not the anchor point for physics.
    # The actual sling anchor for physics/launch calculations is `sling_anchor = (130, 380)` (base coords)
    # and then scaled: `sx, sy = scale_pos(*sling_anchor)` in `sling_action`.
    # For Patapim's potion, we'll use its current position as the origin.


    base_slingl_x, base_slingl_y = 120, 370
    base_slingr_x, base_slingr_y = 120, 370
    
    
    def get_sling_positions():
        # Uses module-level base_slingl_x, base_slingl_y, etc.
        return scale_pos(base_slingl_x, base_slingl_y) # Assuming base_slingr_x/y are same for this return

    bold_font = pg.font.SysFont("arial", 20, bold=True)

    def screen_to_world(screen_x, screen_y, current_screen_height, current_scale_x, current_scale_y):
        world_x = screen_x / current_scale_x
        world_y = (current_screen_height - screen_y) / current_scale_y 
        return Vec2d(world_x, world_y)
    bold_font2 = pg.font.SysFont("arial", 30, bold=True)
    bold_font3 = pg.font.SysFont("arial", 50, bold=True)
        
    sahur_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/sahur.mp3"))
    trala_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/trala.mp3"))
    liri_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/liri.mp3"))
    palocleves_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/ballerina.mp3"))
    patapim_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/patapim.mp3"))
    #patapim_slowdown_sound = pg.mixer.Sound(load_resource("./resources/sounds/patapim_slowdown.mp3"))
    glorbo_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/glorbo.mp3"))
    bomb_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/bomb.mp3"))
    bird_exit_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/bird_exit.mp3"))
    bird_exit_sound.set_volume(0.5) # Set bird exit sound volume to 50%

    # New ability activation sounds
    sahur_bat_ability_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/bat_swing.mp3"))
    bomb_wind_ability_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/wind.mp3"))
    glorbo_balloon_ability_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/balloon.mp3"))
    patapim_throw_ability_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/throw.mp3"))
    trala_turbo_ability_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/turbo_1.mp3"))
    potion_break_sound = pg.mixer.Sound(load_resource("./resources/sounds/bird_sounds/potion_break.mp3"))
    splash_sound = pg.mixer.Sound(load_resource("./resources/sounds/splash.mp3"))
    splash_sound.set_volume(0.3) # Set splash sound volume to 30%
    
    
    bg = pg.image.load(load_resource("./resources/images/bg.png")).convert_alpha()

    buttons = None # Initialize to None
    buttons_path = "" # Initialize path variable
    try:
        buttons_path = load_resource("./resources/images/buttons.png")
        print(f"DEBUG: Attempting to load buttons from: {buttons_path}")
        buttons = pg.image.load(buttons_path).convert_alpha()
    except pg.error as e:
        print(f"CRITICAL PYGAME ERROR: Failed to load buttons.png: {e}")
        print(f"Attempted path: {buttons_path}")
        pg.quit()
        sys.exit()
    except Exception as e: # Catch any other unexpected error during loading
        print(f"CRITICAL UNEXPECTED ERROR: Failed to load buttons.png: {e}")
        if buttons_path: # Check if path was set
            print(f"Attempted path: {buttons_path}")
        pg.quit()
        sys.exit()

    if not buttons: 
        print("CRITICAL ERROR: buttons.png loaded as None or image loading failed silently. Exiting.")
        pg.quit()
        sys.exit()
    else:
        print("DEBUG: 'buttons.png' loaded successfully and is a valid Surface.")
    buttons2 = pg.image.load(load_resource("./resources/images/buttons2.png")).convert_alpha()
    menu_son = pg.image.load(load_resource("./resources/images/menu_son.png")).convert_alpha()
    menu_sof = pg.image.load(load_resource("./resources/images/menu_sof.png")).convert_alpha()
    menu_son = pg.transform.scale(menu_son, (250*scale_x, screen_height))
    menu_sof = pg.transform.scale(menu_sof, (250*scale_x, screen_height))
    
    terrain_texture = pg.image.load(load_resource("./resources/images/terrain_fill.png")).convert_alpha()
    water_texture = pg.image.load(load_resource("./resources/images/terrain_fill_water.png")).convert_alpha() # Load water texture


    # --- Define buttons from the 'buttons' spritesheet ---
    rect = pg.Rect(32, 19, 122 - 32, 116 - 19)
    replay_button = buttons.subsurface(rect).copy()

    # --- Stop/Pause Button Setup (replaces old stop_button) ---
    stop_button_rect_def = pg.Rect(25, 142, 122 - 25, 243 - 142)
    stop_button_original_unscaled = buttons.subsurface(stop_button_rect_def).copy()
    stop_button_original = pg.transform.scale(stop_button_original_unscaled, (65, 65)) # Base size for logic
    stop_button_darkened = stop_button_original.copy()
    darken_overlay_surface = pg.Surface(stop_button_darkened.get_size(), pg.SRCALPHA)
    darken_overlay_surface.fill((0, 0, 0, 70)) # Semi-transparent black for darkening
    stop_button_darkened.blit(darken_overlay_surface, (0,0))
    
    stop_button_is_hovered = False
    stop_button_is_pressed = False 
    stop_button_pressed_scale_factor = 0.9

    rect = pg.Rect(173, 444, 274 - 173, 552 - 444)
    next_button = buttons.subsurface(rect).copy()

    rect = pg.Rect(165, 132, 277 - 165, 259 - 132)
    exit_button = buttons.subsurface(rect).copy()

    rect = pg.Rect(18, 264, 114 - 18, 365 - 264)
    go_button = buttons.subsurface(rect).copy()

    rect = pg.Rect(167, 288, 284 - 167, 409 - 288)
    sound_button = buttons.subsurface(rect).copy()

    sound_button_scaled_width = int(sound_button.get_width() * 0.5)
    sound_button_scaled_height = int(sound_button.get_height() * 0.5)

    sound_button = pg.transform.scale(sound_button, (sound_button_scaled_width, sound_button_scaled_height))
    # Make sure this line is not indented if it's at the module level

    click_sound = pg.mixer.Sound(load_resource("./resources/sounds/click.mp3"))

    # Load ground collision sounds
    ground_collision_sounds_list = []
    ground_sounds_folder_path = "./resources/sounds/ground_collision_sounds"
    try:
        # Ensure the base path to the folder is resolved correctly
        resolved_folder_path = load_resource(ground_sounds_folder_path)
        if os.path.isdir(resolved_folder_path):
            sound_files = os.listdir(resolved_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")): # Check for common sound formats
                    try:
                        # Construct the relative path for load_resource again for each file
                        full_sound_path_for_load_resource = os.path.join(ground_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path_for_load_resource))
                        ground_collision_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load sound file {s_file} from {ground_sounds_folder_path}: {e}")
            
            if not ground_collision_sounds_list:
                print(f"Warning: No ground collision sounds loaded from {resolved_folder_path}. Check folder and files.")
            else: # If sounds were loaded, set their volume
                for sound_effect in ground_collision_sounds_list:
                    sound_effect.set_volume(0.15) # Set volume to 30% (adjust as needed)
                print(f"Info: Ground collision sounds volume set to 30%.")
        else:
            print(f"Warning: Ground collision sounds folder not found: {resolved_folder_path}")
    except Exception as e: # Catching a broader exception for listing/path issues
        print(f"Warning: An error occurred while trying to access ground collision sounds folder '{ground_sounds_folder_path}': {e}")

    # Load explosion sounds (This block was already present, ensuring it's after button loading is fine)
    explosion_sounds_list = []
    # Using the same folder as bird ability explosions for now.
    # If you have a different folder for general/TNT explosions, change explosion_sounds_folder_path.
    explosion_sounds_folder_path = "./resources/sounds/bird_sounds/explosions/"
    try:
        resolved_explosion_folder_path = load_resource(explosion_sounds_folder_path)
        if os.path.isdir(resolved_explosion_folder_path):
            sound_files = os.listdir(resolved_explosion_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")):
                    try:
                        full_sound_path_for_load_resource = os.path.join(explosion_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path_for_load_resource))
                        loaded_sound.set_volume(0.5) # Set volume to 50% for general explosions
                        explosion_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load explosion sound file {s_file} from {explosion_sounds_folder_path}: {e}")
            if not explosion_sounds_list:
                print(f"Warning: No explosion sounds loaded from {resolved_explosion_folder_path}. Check folder and files.")
        else:
            print(f"Warning: Explosion sounds folder not found: {resolved_explosion_folder_path}")
    except Exception as e:
        print(f"Warning: An error occurred while trying to access explosion sounds folder '{explosion_sounds_folder_path}': {e}")

    # Load bird ability explosion sounds (e.g., Palocleves, Bomb's projectile)
    bird_ability_explosion_sounds_list = []
    bird_explosion_sounds_folder_path = "./resources/sounds/bird_sounds/explosions/"
    try:
        resolved_bird_explosion_folder_path = load_resource(bird_explosion_sounds_folder_path)
        if os.path.isdir(resolved_bird_explosion_folder_path):
            sound_files = os.listdir(resolved_bird_explosion_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")):
                    try:
                        full_sound_path_for_load_resource = os.path.join(bird_explosion_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path_for_load_resource))
                        bird_ability_explosion_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load bird explosion sound file {s_file} from {bird_explosion_sounds_folder_path}: {e}")
            
            if not bird_ability_explosion_sounds_list:
                print(f"Warning: No bird ability explosion sounds loaded from {resolved_bird_explosion_folder_path}. Check folder and files.")
            else:
                for sound_effect in bird_ability_explosion_sounds_list:
                    sound_effect.set_volume(0.5) # Set volume to 50%
                print(f"Info: Bird ability explosion sounds volume set to 50%.")
        else:
            print(f"Warning: Bird ability explosion sounds folder not found: {resolved_bird_explosion_folder_path}")
    except Exception as e:
        print(f"Warning: An error occurred while trying to access bird ability explosion sounds folder '{bird_explosion_sounds_folder_path}': {e}")

    # Load wood break sounds
    wood_break_sounds_list = []
    wood_break_sounds_folder_path = "./resources/sounds/wood_break_sounds/"
    try:
        resolved_wood_folder_path = load_resource(wood_break_sounds_folder_path)
        if os.path.isdir(resolved_wood_folder_path):
            sound_files = os.listdir(resolved_wood_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")):
                    try:
                        full_sound_path = os.path.join(wood_break_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path))
                        loaded_sound.set_volume(0.25) # Set volume to 25%
                        wood_break_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load wood break sound {s_file}: {e}")
            if not wood_break_sounds_list:
                print(f"Warning: No wood break sounds loaded from {resolved_wood_folder_path}.")
        else:
            print(f"Warning: Wood break sounds folder not found: {resolved_wood_folder_path}")
    except Exception as e:
        print(f"Warning: Error accessing wood break sounds folder '{wood_break_sounds_folder_path}': {e}")

    # Load stone break sounds
    stone_break_sounds_list = []
    stone_break_sounds_folder_path = "./resources/sounds/stone_break_sounds/"
    try:
        resolved_stone_folder_path = load_resource(stone_break_sounds_folder_path)
        if os.path.isdir(resolved_stone_folder_path):
            sound_files = os.listdir(resolved_stone_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")):
                    try:
                        full_sound_path = os.path.join(stone_break_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path))
                        loaded_sound.set_volume(0.25) # Set volume to 25%
                        stone_break_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load stone break sound {s_file}: {e}")
            if not stone_break_sounds_list:
                print(f"Warning: No stone break sounds loaded from {resolved_stone_folder_path}.")
        else:
            print(f"Warning: Stone break sounds folder not found: {resolved_stone_folder_path}")
    except Exception as e:
        print(f"Warning: Error accessing stone break sounds folder '{stone_break_sounds_folder_path}': {e}")

    # Load glass break sounds
    glass_break_sounds_list = []
    glass_break_sounds_folder_path = "./resources/sounds/glass_break_sounds/" # Ensure this folder exists
    try:
        resolved_glass_folder_path = load_resource(glass_break_sounds_folder_path)
        if os.path.isdir(resolved_glass_folder_path):
            sound_files = os.listdir(resolved_glass_folder_path)
            for s_file in sound_files:
                if s_file.lower().endswith((".wav", ".ogg", ".mp3")):
                    try:
                        full_sound_path = os.path.join(glass_break_sounds_folder_path, s_file)
                        loaded_sound = pg.mixer.Sound(load_resource(full_sound_path))
                        loaded_sound.set_volume(0.25) # Set volume to 25%
                        glass_break_sounds_list.append(loaded_sound)
                    except pg.error as e:
                        print(f"Warning: Could not load glass break sound {s_file}: {e}")
            if not glass_break_sounds_list:
                print(f"Warning: No glass break sounds loaded from {resolved_glass_folder_path}. Create the folder and add sounds.")
        else:
            print(f"Warning: Glass break sounds folder not found: {resolved_glass_folder_path}")
    except Exception as e:
        print(f"Warning: Error accessing glass break sounds folder '{glass_break_sounds_folder_path}': {e}")
    muted_sound_button_blue = pg.image.load(load_resource("./resources/images/muted_sound_button_blue.png")).convert_alpha()
    sound_button_blue = pg.image.load(load_resource("./resources/images/sound_button_blue.png")).convert_alpha()

    rect = pg.Rect(26, 385, 117 - 26, 478 - 385)
    menu_button = buttons.subsurface(rect).copy()

    rect = pg.Rect(291, 11, 547 - 291, 181 - 11)
    play_button = buttons.subsurface(rect).copy()
    play_button_scaled = pg.transform.scale(play_button, scale_size(play_button.get_width(), play_button.get_height()))


    back_arrow = pg.image.load(load_resource("./resources/images/back_arrow.png")).convert_alpha()
    exit_button = pg.image.load(load_resource("./resources/images/exit_button.png")).convert_alpha()
    next_arrow_button = pg.transform.flip(back_arrow, True, False) # Flipped horizontally for "next"
    settings_button = pg.image.load(load_resource("./resources/images/settings_button.png")).convert_alpha()


    wood1 = pg.image.load(load_resource("./resources/images/wood.png")).convert_alpha()
    star1 = pg.image.load(load_resource("./resources/images/gold_star.png")).convert_alpha()

    sling = pg.image.load(load_resource("./resources/images/sling.png")).convert_alpha()
    slingl = pg.image.load(load_resource("./resources/images/slingl.png")).convert_alpha()
    slingr = pg.image.load(load_resource("./resources/images/slingr.png")).convert_alpha()

    # Moved scale factors here as they are used before their original definition
    bird_scale_factor = 0.3
    pig_scale_factor = 1
    star13_scale_factor = 0.5
    star2_scale_factor = 1

    n11 = pg.image.load(load_resource("./resources/images/n1.1.png")).convert_alpha()
    n12 = pg.image.load(load_resource("./resources/images/n1.2.png")).convert_alpha()
    n21 = pg.image.load(load_resource("./resources/images/n2.1.png")).convert_alpha()
    n22 = pg.image.load(load_resource("./resources/images/n2.2.png")).convert_alpha()
    n31 = pg.image.load(load_resource("./resources/images/n3.1.png")).convert_alpha()
    n32 = pg.image.load(load_resource("./resources/images/n3.2.png")).convert_alpha()
    n41 = pg.image.load(load_resource("./resources/images/n4.1.png")).convert_alpha()
    n42 = pg.image.load(load_resource("./resources/images/n4.2.png")).convert_alpha()
    n51 = pg.image.load(load_resource("./resources/images/n5.1.png")).convert_alpha()
    n52 = pg.image.load(load_resource("./resources/images/n5.2.png")).convert_alpha()

    trala = pg.image.load(load_resource("./resources/images/trala.png")).convert_alpha()
    sahur = pg.image.load(load_resource("./resources/images/sahur.png")).convert_alpha()

    n11_scaled_width = int(n11.get_width() * pig_scale_factor)
    n11_scaled_height = int(n11.get_height() * pig_scale_factor)

    sahur_scaled_width = int(sahur.get_width() * bird_scale_factor)
    sahur_scaled_height = int(sahur.get_height() * bird_scale_factor)

    star13_scaled_width = int(star1.get_width() * star13_scale_factor)
    star13_scaled_height = int(star1.get_height() * star13_scale_factor)

    #star1 = pg.transform.scale(star1, (star13_scaled_width, star13_scaled_height))

    # Calculate initial scaled dimensions
    slingl_scaled_width = int(slingl.get_width() * 0.135)  # design const
    slingl_scaled_height = int(slingl.get_height() * 0.135) # design const
    slingr_scaled_width = int(slingr.get_width() * 0.05) # design const
    slingr_scaled_height = int(slingr.get_height() * 0.05) # design const

    # Initial scaling of sling images
    slingl = pg.transform.scale(slingl, scale_size(slingl_scaled_width, slingl_scaled_height))
    slingr = pg.transform.scale(slingr, scale_size(slingr_scaled_width, slingr_scaled_height))

    n11 = pg.transform.scale(n11, (n11_scaled_width, n11_scaled_height))
    sahur = pg.transform.scale(sahur, (sahur_scaled_width, sahur_scaled_height))
    #print(slingr.get_width(), slingr.get_height())
    #print(slingl.get_width(), slingl.get_height())


    bomb0 = pg.image.load(load_resource("./resources/images/bomb0.png")).convert_alpha()
    bomb1 = pg.image.load(load_resource("./resources/images/bomb.png")).convert_alpha()
    bomb2 = pg.image.load(load_resource("./resources/images/bomb2.png")).convert_alpha()

    glorbo = pg.image.load(load_resource("./resources/images/glorbo.png")).convert_alpha()
    liri = pg.image.load(load_resource("./resources/images/liri.png")).convert_alpha()
    liri = pg.transform.scale(liri,(liri.get_width()*0.1,liri.get_height()*0.1))

    patapim_full = pg.image.load(load_resource("./resources/images/patapim.png")).convert_alpha()

    levels_menu = pg.image.load(load_resource("./resources/images/levels_menu.png")).convert_alpha()
    rect = pg.Rect(220, 79, 359 - 220, 218 - 79)
    level_icon = pg.transform.scale(levels_menu.subsurface(rect).copy(), (100, 100))
    rect = pg.Rect(1563, 600, 1700 - 1563, 740 - 600)
    locked_level_icon = pg.transform.scale(levels_menu.subsurface(rect).copy(), (100, 100))

    clock = pg.time.Clock()

    running = True

    # base physics

    space = pm.Space()
    space.gravity = (0.0, -300.0) # Reduced gravity for longer travel distance


    # STATIC FLOOR

    floor = Static_line(screen_height,screen_width,space)

    def get_all_files_listdir(directory):
        all_files = []
        try:
            for entry in os.listdir(load_resource(directory)):
                path = os.path.join(load_resource(directory), entry)
                if os.path.isfile(path):
                    all_files.append(entry)
        except FileNotFoundError:
            print(f"Error: Directory not found: {directory}")
        return all_files

    win_imgs = get_all_files_listdir("./resources/images/win_imgs")
    lose_imgs = get_all_files_listdir("./resources/images/lose_imgs")

    buttons = pg.image.load(load_resource("./resources/images/buttons.png")).convert_alpha()

    def to_pygame(p):
        x, y = p.x, -p.y + 600
        return scale_pos(x, y)

    def vector(p0, p1):  # return vector of p1 and p2
        a = p1[0] - p0[0] # x component
        b = p1[1] - p0[1] # y component
        return a, b

    def unit_vector(v): # get unit vector
        h = ((v[0] ** 2 + (v[1] ** 2)) ** 0.5)
        if h == 0:
            h = 0.000000000000001
        ua = v[0] / h
        ub = v[1] / h
        return ua, ub

    def distance(x0, y0, x, y): # calculate distance between two points
        dx = x - x0
        dy = y - y0
        d = ((dx ** 2) + (dy ** 2)) ** 0.5
        return d

    def sling_action(): # change pos of sling
        global launch_angle
        global x_mouse # mouse coords are global
        global y_mouse
        global impulse_x
        global impulse_y
        global sling_anchor
        global mouse_distance
        global pu

        sx, sy = scale_pos(*sling_anchor)
        mx, my = x_mouse, y_mouse

        v = vector((sx, sy), (mx, my))
        uv = unit_vector(v) # unit vector for direction
        uv1 = uv[0]
        uv2 = uv[1]
        # distance from sling anchor to mouse
        mouse_distance_raw = distance(sx, sy, mx, my)

        if mouse_distance_raw > rope_length:
            mouse_distance = rope_length
            pu = uv1 * rope_length + sx, uv2 * rope_length + sy
            x_sahur = pu[0] - sahur.get_width() // 2
            y_sahur = pu[1] - sahur.get_height() // 2
            # Draw bird and sling lines if bird is available
            if len(level.level_birds) >= 0:

                screen.blit(bird_img, (x_sahur, y_sahur))
                slingl_x, slingl_y = get_sling_positions()
                slingr_x, slingr_y = get_sling_positions()
                pg.draw.line(screen, (0, 0, 0), (slingr_x + 4 * scale_x, slingr_y + 3 * scale_y), pu, 5)
                pg.draw.line(screen, (0, 0, 0), (slingl_x + 2 * scale_x, slingl_y + 13 * scale_y), pu, 5)
        else:
            mouse_distance = mouse_distance_raw
            pu = mx, my
            x_sahur = mx - sahur.get_width() // 2
            y_sahur = my - sahur.get_height() // 2
            # Draw bird and sling lines if bird is available
            if len(level.level_birds) >= 0:

                screen.blit(bird_img, (x_sahur, y_sahur))
                slingl_x, slingl_y = get_sling_positions()
                slingr_x, slingr_y = get_sling_positions()
                pg.draw.line(screen, (0, 0, 0), (slingr_x + 4 * scale_x, slingr_y + 3 * scale_y), (mx, my), 5)
                pg.draw.line(screen, (0, 0, 0), (slingl_x + 2 * scale_x, slingl_y + 13 * scale_y), (mx, my), 5)
        # calculate angle for launch
        dy = sy - pu[1]
        dx = sx - pu[0]
        if dx == 0:
            dx = 0.000000000000001

        angle = math.atan2(dy, dx)
        launch_angle = angle

    def restart():
        global mouse_pressed_to_shoot, restart_counter
        mouse_pressed_to_shoot = False
        restart_counter = False

        # First, clean up any ability polygons (like Sahur's bat)
        # These are often tracked in the 'columns' list.
        for bird_instance in list(birds): # Iterate a copy
            if hasattr(bird_instance, 'ability_polygon') and bird_instance.ability_polygon:
                poly = bird_instance.ability_polygon
                if poly.shape and poly.body and poly.shape in space.shapes:
                    space.remove(poly.shape, poly.body)
                poly.in_space = False # Mark the Polygon object
                if poly in columns: # Remove from the 'columns' list
                    columns.remove(poly)
                bird_instance.ability_polygon = None # Nullify bird's reference

        # Next, remove all active birds from the game and space
        for bird_instance in list(birds): # Iterate a copy
            if bird_instance.shape and bird_instance.body and bird_instance.shape in space.shapes:
                space.remove(bird_instance.shape, bird_instance.body)
        birds.clear()

        # Then, remove all pigs
        for pig_instance in list(pigs): # Iterate a copy
            if pig_instance.shape and pig_instance.body and pig_instance.shape in space.shapes:
                space.remove(pig_instance.shape, pig_instance.body)
        pigs.clear()

        # Finally, clear out all other game elements (blocks, etc.)
        # Note: some 'columns' might be ability polygons already removed.
        # The Polygon class's 'in_space' helps track this.
        
        # Columns
        for column_item in list(columns):
            if column_item.shape and column_item.body and column_item.shape in space.shapes:
                space.remove(column_item.shape, column_item.body)
            column_item.in_space = False
        columns.clear()

        # Beams
        for beam_item in list(beams):
            if beam_item.shape and beam_item.body and beam_item.shape in space.shapes:
                space.remove(beam_item.shape, beam_item.body)
            beam_item.in_space = False
        beams.clear()
            
        # Circles
        for circle_item in list(circles):
            if circle_item.shape and circle_item.body and circle_item.shape in space.shapes:
                space.remove(circle_item.shape, circle_item.body)
            circle_item.in_space = False
        circles.clear()

        # Triangles
        for triangle_item in list(triangles):
            if triangle_item.shape and triangle_item.body and triangle_item.shape in space.shapes:
                space.remove(triangle_item.shape, triangle_item.body)
            triangle_item.in_space = False
        triangles.clear()

    def apply_potion_antigravity(impact_position, space_ref):
        """Initiates a growth effect on pigs within a radius."""
        global pigs # List of pig instances
        global POTION_EFFECT_RADIUS, growing_pigs_effects, POTION_PIG_GROWTH_SCALE_MULTIPLIER
        
        current_effect_start_time = time.time()

        for pig_instance in pigs:
            if pig_instance.body and pig_instance.body.space: # Ensure pig is valid and in space
                distance = pig_instance.body.position.get_distance(impact_position)
                if distance < POTION_EFFECT_RADIUS:
                    # Only apply if not already growing or fully grown from this effect type
                    if pig_instance not in growing_pigs_effects and \
                        (not hasattr(pig_instance, 'is_potion_grown') or not pig_instance.is_potion_grown):
                        
                        # Store original properties for interpolation and potential reversion (if needed later)
                        # pig_instance.radius is used for drawing, pig_instance.shape.radius for physics
                        growing_pigs_effects[pig_instance] = {
                            "start_time": current_effect_start_time,
                            "original_visual_radius": pig_instance.radius, # The one used for drawing
                            "original_physics_radius": pig_instance.shape.radius, # The Pymunk shape radius
                            "original_mass": pig_instance.body.mass
                        }
                        pig_instance.is_potion_effect_active = True # Custom flag on pig instance
                        print(f"DEBUG: Potion effect: Pig at {pig_instance.body.position} starting to grow.")
                    elif pig_instance in growing_pigs_effects:
                        # If already growing, maybe refresh start_time to extend effect?
                        # For now, let's not re-trigger if already in the dictionary.
                        pass



    def post_solve_bird_pig(arbiter, space, _):
        a, b = arbiter.shapes
        bird_body = a.body
        pig_body = b.body
        bird_momentum = bird_body.mass * bird_body.velocity.length # for damage calc
        
        # Adjusted damage calculation for bird hitting pig
        damage = 0
        if arbiter.total_impulse.length > 500: # Higher impulse threshold for significant damage
            momentum_damage_factor = 0.06 # Reduced factor for more balanced damage
            damage = bird_momentum * momentum_damage_factor

        pig_to_remove = []
        for pig in pigs:
            if pig.body == pig_body and damage > 0: # Apply damage if calculated
                pig.life -= damage # deal damage
                if pig.life <= 0:
                    # Add impact visual for bird-pig KO if impulse was significant
                    # Check if arbiter.contact_point_set.points exists before accessing
                    if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and \
                        arbiter.contact_point_set.points:
                        contact_point_world = arbiter.contact_point_set.points[0].point_a # Or point_b, should be close
                        impact_visual = ch.Explosion(
                            center_pos_world=contact_point_world,
                            frame_folder_path=IMPACT_FRAME_FOLDER,
                            frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                            scale_factor_tuple_px=IMPACT_SCALE_PX,
                            to_pygame_func=to_pygame
                        )
                        active_explosions.add(impact_visual)
                    pig_to_remove.append(pig)
                    global score
                    score += PIG_KO_SCORE # Global score is modified

        for pig in pig_to_remove:
            if pig.shape and pig.body: # Ensure pig has shape and body
                if pig.shape in space.shapes: # Check if shape is in space
                    space.remove(pig.shape, pig.body)
            if pig in pigs: # Check if pig is in the list
                pigs.remove(pig)
            
    # def trigger_custom_polygon_explosion(exploding_poly, space_ref, pigs_list, all_destructible_polys_list, active_explosions_group, to_pygame_func, sound_on_flag, explosion_sounds_list_ref):
    # This function definition was moved up to avoid NameError, as it's called by post_solve_bird_wood
    # Ensure it's defined before its first call or declared global if that's the structure.
    # For this diff, I'll assume it's defined above or correctly scoped.
    # No change to the function signature or body itself based on this specific request for TNT sound,
    # as it already plays a sound from explosion_sounds_list_ref (general explosions).
            
    def trigger_custom_polygon_explosion(exploding_poly, space_ref, pigs_list, all_destructible_polys_list, active_explosions_group, to_pygame_func, sound_on_flag, explosion_sounds_list_ref):
        """Handles the explosion effects for a custom exploding polygon."""
        global score # Allow modification of global score

        if not exploding_poly.is_explosive or exploding_poly.has_exploded or not exploding_poly.in_space:
            return

        exploding_poly.has_exploded = True
        explosion_center = exploding_poly.body.position

        # Use parameters from the exploding_poly instance
        radius = exploding_poly.explosion_radius
        damage_pigs = exploding_poly.explosion_damage_pigs
        damage_polys = exploding_poly.explosion_damage_polys
        knockback_base = exploding_poly.explosion_knockback_base

        print(f"DEBUG: Custom polygon '{exploding_poly.element_type}' exploding at {explosion_center}. Radius: {radius}, PigDmg: {damage_pigs}, PolyDmg: {damage_polys}")

        if sound_on_flag and explosion_sounds_list_ref:
            random.choice(explosion_sounds_list_ref).play()

        explosion_visual = ch.Explosion(
            center_pos_world=explosion_center,
            frame_folder_path=BOMB_EXPLOSION_FRAME_FOLDER, # Using generic explosion visual for now
            frame_duration_ms=BOMB_EXPLOSION_FRAME_DURATION_MS,
            scale_factor_tuple_px=BOMB_EXPLOSION_SCALE_PX,
            to_pygame_func=to_pygame_func
        )
        active_explosions_group.add(explosion_visual)

        # --- Damage and Knockback PIGS ---
        pigs_hit_by_explosion = []
        for pig_obj in pigs_list:
            if not pig_obj.body: continue
            dist_vec = pig_obj.body.position - explosion_center
            distance = dist_vec.length
            if distance < radius:
                damage_falloff = max(0, (radius - distance) / radius)
                actual_damage = damage_pigs * damage_falloff
                pig_obj.life -= actual_damage
                if pig_obj.life <= 0:
                    pigs_hit_by_explosion.append(pig_obj)
                    score += PIG_KO_SCORE
                if distance > 0: # Apply knockback
                    knockback_dir = dist_vec.normalized()
                    pig_obj.body.apply_impulse_at_local_point(knockback_dir * knockback_base * damage_falloff, (0,0))

        # --- Damage and Knockback POLYGONS ---
        polys_hit_by_explosion = []
        for poly_obj in all_destructible_polys_list:
            if poly_obj == exploding_poly or not poly_obj.body or poly_obj.body.body_type == pm.Body.STATIC:
                continue
            dist_vec = poly_obj.body.position - explosion_center
            distance = dist_vec.length
            if distance < radius:
                damage_falloff = max(0, (radius - distance) / radius)
                actual_damage = damage_polys * damage_falloff
                poly_obj.life -= actual_damage
                if poly_obj.life <= 0:
                    polys_hit_by_explosion.append(poly_obj)
                    score += POLY_DESTROY_SCORE
                if distance > 0: # Apply knockback
                    knockback_dir = dist_vec.normalized()
                    poly_obj.body.apply_impulse_at_local_point(knockback_dir * knockback_base * damage_falloff, (0,0))

        # Remove the exploding polygon itself
        if exploding_poly.in_space:
            space_ref.remove(exploding_poly.shape, exploding_poly.body)
            exploding_poly.in_space = False
            # Also remove from its list (columns, beams, etc.) - this needs to be handled where it's called or by passing the list

    def post_solve_bird_wood(arbiter, space, _):
        global beams, columns, triangles, circles, score # Added score to existing globals
        element_to_remove = []
        a, b = arbiter.shapes
        bird_body = a.body
        wood_body = b.body  # Get the wood's body.  Need this.
        bird_momentum = bird_body.mass * bird_body.velocity.length # Bird's momentum

        # Find the specific bird instance involved in this collision
        colliding_bird_instance = None
        for bird_obj in birds: # Iterate through the global list of active birds
            if bird_obj.body == bird_body:
                colliding_bird_instance = bird_obj
                break

        damage = 0
        # Use existing impulse threshold, adjust damage factor
        if arbiter.total_impulse.length > 0: # Existing threshold for bird hitting wood
            bird_has_hit_ground = False
            if colliding_bird_instance:
                bird_has_hit_ground = colliding_bird_instance.bird_hit_ground

            if bird_has_hit_ground and not isinstance(colliding_bird_instance, ch.Liri):
                momentum_damage_factor = 0.01
            else:
                momentum_damage_factor = 0.03
            damage = bird_momentum * momentum_damage_factor
                
            for element in columns + circles + beams + triangles:
                if element.shape.body == wood_body:  # Change to check the body
                    element.life -= damage
                    print(f"DEBUG: Bird (ground_hit: {bird_has_hit_ground}) hit {element.material_type} {element.element_type}. Damage: {damage:.2f}. Life: {element.life:.2f}")
                    
                    # Check if this element is an exploding crate and should explode
                    if element.is_explosive and not element.has_exploded and element.life <= 0:
                        trigger_custom_polygon_explosion(
                            exploding_poly=element, space_ref=space, pigs_list=pigs,
                            all_destructible_polys_list=columns + beams + circles + triangles,
                            active_explosions_group=active_explosions,
                            to_pygame_func=to_pygame, sound_on_flag=sound_on,
                            explosion_sounds_list_ref=explosion_sounds_list
                        )

                    if element.life <= 0:
                        element_to_remove.append(element)
                        score += POLY_DESTROY_SCORE # Use constant

                        # Play material break sound if not an exploding crate about to explode
                        if not (element.is_explosive and not element.has_exploded):
                            if sound_on:
                                if element.material_type == "wood" and wood_break_sounds_list:
                                    random.choice(wood_break_sounds_list).play()
                                elif element.material_type == "stone" and stone_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                                elif element.material_type == "glass" and glass_break_sounds_list:
                                    random.choice(glass_break_sounds_list).play()
                                # Add elif for "glass" and other materials here if needed

                        
                        # Add impact visual if impulse was significant
                        if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and arbiter.contact_point_set.points:
                            contact_point_world = arbiter.contact_point_set.points[0].point_a
                            impact_visual = ch.Explosion(
                                center_pos_world=contact_point_world,
                                frame_folder_path=IMPACT_FRAME_FOLDER,
                                frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                                scale_factor_tuple_px=IMPACT_SCALE_PX,
                                to_pygame_func=to_pygame
                            )
                            active_explosions.add(impact_visual)
        for element in element_to_remove:
            if element.in_space: # Check if not already removed (e.g., by explosion)
                space.remove(element.shape, element.body)
                element.in_space = False # Mark as removed
                if element in columns: columns.remove(element)
                elif element in beams: beams.remove(element)
                elif element in circles: circles.remove(element)
                elif element in triangles: triangles.remove(element)

    def post_solve_pig_wood(arbiter, space, _):
        polys_in_explosion_to_remove_locally = []
        pig_to_remove = []
        pig_shape, wood_poly_shape = arbiter.shapes # wood_poly_shape is the type 2 object (polygon/bat)

        is_sahurs_bat_collision = False
        is_bombs_bomb_collision = False
        is_patapims_potion_collision = False # Initialize to False
        source_ability_polygon_object = None # This will be the Polygon instance of the bat or bomb

        if birds: # Ensure there's an active bird
            active_bird = birds[-1] # The bird currently in play
            if isinstance(active_bird, ch.Sahur) and \
                active_bird.fahigkeit_verwendet and \
                hasattr(active_bird, 'ability_polygon') and \
                active_bird.ability_polygon is not None and \
                active_bird.ability_polygon.shape == wood_poly_shape:
                is_sahurs_bat_collision = True
                source_ability_polygon_object = active_bird.ability_polygon
            elif isinstance(active_bird, ch.Bomb) and \
                active_bird.fahigkeit_verwendet and \
                hasattr(active_bird, 'ability_polygon') and \
                active_bird.ability_polygon is not None and \
                active_bird.ability_polygon.shape == wood_poly_shape:
                is_bombs_bomb_collision = True
                source_ability_polygon_object = active_bird.ability_polygon
            elif isinstance(active_bird, ch.Patapim) and \
                active_bird.fahigkeit_verwendet and \
                hasattr(active_bird, 'ability_polygon') and \
                active_bird.ability_polygon is not None and \
                active_bird.ability_polygon.shape == wood_poly_shape:
                is_patapims_potion_collision = True
                source_ability_polygon_object = active_bird.ability_polygon
        
        # --- Handle Sahur's Bat Collision ---
        if is_sahurs_bat_collision: # Sahur's bat is special
            if arbiter.total_impulse.length > 0: # Minimal impulse to confirm "real" collision
                sahur_bat_damage = 200000
                for pig in pigs:
                    if pig.shape == pig_shape:
                        pig.life -= sahur_bat_damage
                        if pig.life <= 0 and pig not in pig_to_remove:
                            pig_to_remove.append(pig)
                            global score
                            score += PIG_KO_SCORE
                        break
        # --- Handle Bomb's Projectile Collision (Explosion) ---
        elif is_bombs_bomb_collision:
            # Ensure the bomb projectile exists and is still in space before exploding
            if arbiter.total_impulse.length > 10.0 and \
                source_ability_polygon_object and source_ability_polygon_object.in_space:
                
                explosion_center = source_ability_polygon_object.body.position
                explosion_radius = BOMB_PROJECTILE_EXPLOSION_RADIUS
                explosion_base_damage_polys = 1700 # Example: 3000 if you want higher poly damage
                explosion_base_damage_pigs = 175

                # Play explosion sound for Bomb's projectile (using bird ability sounds)
                if sound_on and bird_ability_explosion_sounds_list:
                    random.choice(bird_ability_explosion_sounds_list).play()
                
                # Create visual explosion for Bomb's projectile
                explosion_visual = ch.Explosion(
                    center_pos_world=explosion_center,
                    frame_folder_path=BOMB_EXPLOSION_FRAME_FOLDER,
                    frame_duration_ms=BOMB_EXPLOSION_FRAME_DURATION_MS,
                    scale_factor_tuple_px=BOMB_EXPLOSION_SCALE_PX,
                    to_pygame_func=to_pygame
                )
                active_explosions.add(explosion_visual)

                # 1. Damage the directly hit pig (it takes more damage)
                for pig in pigs:
                    if pig.shape == pig_shape:
                        pig.life -= explosion_base_damage_pigs * 1.5 # Direct hit bonus
                        if pig.life <= 0 and pig not in pig_to_remove:
                            pig_to_remove.append(pig)
                            score += PIG_KO_SCORE 
                        break # Found and processed the directly hit pig

                # 2. Damage other pigs in the explosion radius
                for other_pig in pigs+beams+columns+circles+triangles:
                    if other_pig.shape == pig_shape: continue # Skip the directly hit one
                    
                    dist_vec = other_pig.body.position - explosion_center
                    distance = dist_vec.length
                    if distance < explosion_radius:
                        # Damage falloff: closer pigs take more damage
                        damage_falloff_factor = max(0, (explosion_radius - distance) / explosion_radius)
                        actual_damage = explosion_base_damage_pigs * damage_falloff_factor
                        
                        other_pig.life -= actual_damage
                        if other_pig.life <= 0 and other_pig not in pig_to_remove:
                            pig_to_remove.append(other_pig)
                            score += PIG_KO_SCORE

                # 3. Apply Knockback to pigs from Bomb Explosion
                for other_pig in pigs: # Iterate through all pigs
                    if not other_pig.body or other_pig.shape == pig_shape : continue # Skip the directly hit one if it's a pig
                    if other_pig.body.body_type == pm.Body.STATIC: continue

                    dist_vec_knockback = other_pig.body.position - explosion_center
                    distance_knockback = dist_vec_knockback.length
                    if distance_knockback < explosion_radius and distance_knockback > 0: # Must be within radius and not at center
                        knockback_dir = dist_vec_knockback.normalized()
                        # Falloff: stronger closer, weaker further.
                        falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                        knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                        
                        # Apply less knockback to heavier pigs if desired, or keep it consistent
                        # For now, consistent base impulse scaled by falloff
                        other_pig.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))
                        print(f"DEBUG: Bomb explosion knockback on Pig. Impulse: {knockback_impulse_magnitude:.2f}")

                # 3. Damage polygons (blocks) in the explosion radius
                polys_in_explosion_to_remove_locally = [] # Temp list for this specific explosion
                all_destructible_polys = columns + beams + circles + triangles
                for poly_item in all_destructible_polys:
                    if poly_item == source_ability_polygon_object: continue # Don't let bomb damage itself
                    if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue 

                    dist_vec = poly_item.body.position - explosion_center
                    distance = dist_vec.length
                    if distance < explosion_radius:
                        damage_falloff_factor = max(0, (explosion_radius - distance) / explosion_radius)
                        actual_damage = explosion_base_damage_polys * damage_falloff_factor
                        
                        poly_item.life -= actual_damage
                        print(f"DEBUG: Bomb explosion hit {poly_item.material_type} {poly_item.element_type}. Damage: {actual_damage:.2f}. Remaining Life: {poly_item.life:.2f}")
                        if poly_item.life <= 0 and poly_item not in polys_in_explosion_to_remove_locally:
                            polys_in_explosion_to_remove_locally.append(poly_item)
                            score += POLY_DESTROY_SCORE
                            # Play material break sound if not an exploding crate that just exploded
                            if not (poly_item.is_explosive and poly_item.has_exploded): # has_exploded would be true if it just did
                                if sound_on:
                                    if poly_item.material_type == "wood" and wood_break_sounds_list:
                                        random.choice(wood_break_sounds_list).play()
                                    elif poly_item.material_type == "stone" and stone_break_sounds_list:
                                        random.choice(stone_break_sounds_list).play()
                                    elif poly_item.material_type == "glass" and glass_break_sounds_list:
                                        random.choice(glass_break_sounds_list).play()

                # 4. Apply Knockback to polygons from Bomb Explosion
                for poly_item in all_destructible_polys:
                    if poly_item == source_ability_polygon_object: continue # Bomb doesn't knock itself back
                    if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue

                    dist_vec_knockback = poly_item.body.position - explosion_center
                    distance_knockback = dist_vec_knockback.length
                    if distance_knockback < explosion_radius and distance_knockback > 0:
                        knockback_dir = dist_vec_knockback.normalized()
                        falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                        knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                        poly_item.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))
                        print(f"DEBUG: Bomb explosion knockback on {poly_item.material_type} {poly_item.element_type}. Impulse: {knockback_impulse_magnitude:.2f}")
                
                # Remove polygons destroyed by this explosion
                for poly_to_destroy in polys_in_explosion_to_remove_locally:
                    if poly_to_destroy.in_space: # Check again before removal
                        space.remove(poly_to_destroy.shape, poly_to_destroy.body)
                        poly_to_destroy.in_space = False
                        if poly_to_destroy in columns: columns.remove(poly_to_destroy)
                        elif poly_to_destroy in beams: beams.remove(poly_to_destroy)
                        elif poly_to_destroy in circles: circles.remove(poly_to_destroy)
                        elif poly_to_destroy in triangles: triangles.remove(poly_to_destroy)
                
                # 4. Remove the bomb projectile itself after explosion
                if source_ability_polygon_object.in_space: # Check it wasn't already removed
                    space.remove(source_ability_polygon_object.shape, source_ability_polygon_object.body)
                    source_ability_polygon_object.in_space = False
                    if source_ability_polygon_object in columns: # Bomb projectiles are added to columns
                        columns.remove(source_ability_polygon_object)
                    # Nullify the bird's reference to this ability polygon
                    if hasattr(active_bird, 'ability_polygon') and active_bird.ability_polygon == source_ability_polygon_object:
                        active_bird.ability_polygon = None
        # --- Handle Generic Polygon (non-ability) Collision with Pig ---
        elif is_patapims_potion_collision: # Patapim's Potion hit a pig
            if arbiter.total_impulse.length > 10.0 and \
                source_ability_polygon_object and source_ability_polygon_object.in_space:
                print(f"DEBUG: Patapim's potion hit a pig. Removing potion, no explosion.")
                if sound_on:
                    # Play sound before applying effect, so it's tied to the break
                    potion_break_sound.play()

                # --- EXPLOSION LOGIC REMOVED ---
                # The potion will just be removed without AoE effects.

                # Remove the potion projectile itself
                if source_ability_polygon_object.in_space:
                    potion_impact_position = source_ability_polygon_object.body.position
                    apply_potion_antigravity(potion_impact_position, space) # Apply effect

                    space.remove(source_ability_polygon_object.shape, source_ability_polygon_object.body)
                    source_ability_polygon_object.in_space = False
                    if source_ability_polygon_object in columns: columns.remove(source_ability_polygon_object)
                    # Use the stored owner_bird to clear the ability_polygon reference
                    if hasattr(source_ability_polygon_object, 'owner_bird') and source_ability_polygon_object.owner_bird:
                        if getattr(source_ability_polygon_object.owner_bird, 'ability_polygon', None) == source_ability_polygon_object:
                            source_ability_polygon_object.owner_bird.ability_polygon = None
                # Pigs hit directly might still take damage if other general pig-poly collision logic applies,
                # but the potion's specific explosion damage is gone.

        else: # Neither Sahur's bat nor Bomb's projectile - a regular polygon hit a pig
            colliding_poly_object = None
            all_destructible_polys = columns + beams + circles + triangles
            for poly_item in all_destructible_polys:
                if poly_item.shape == wood_poly_shape:
                    colliding_poly_object = poly_item
                    break
            
            # Find the Pig instance for pig_shape
            actual_pig_instance = None
            for p_instance in pigs:
                if p_instance.shape == pig_shape:
                    actual_pig_instance = p_instance
                    break
            
            # Proceed if both pig and polygon instances are found
            if actual_pig_instance and colliding_poly_object:
                # General collision impulse threshold for any interaction
                if arbiter.total_impulse.length > 900: 
                    
                    # Part 1: Damage TO THE POLYGON from the Pig's momentum (User's Request)
                    if colliding_poly_object.body.body_type == pm.Body.DYNAMIC and \
                        colliding_poly_object.element_type != "bats": # Ensure polygon is dynamic and not a special bat
                        
                        momentum_pig = actual_pig_instance.body.mass * actual_pig_instance.body.velocity.length
                        # TUNABLE: Factor to scale pig's momentum to damage dealt to polygon
                        poly_damage_from_pig_momentum_factor = 0.05 
                        
                        damage_to_poly = momentum_pig * poly_damage_from_pig_momentum_factor
                        colliding_poly_object.life -= damage_to_poly
                        print(f"DEBUG: Pig (momentum {momentum_pig:.2f}) hit {colliding_poly_object.material_type} {colliding_poly_object.element_type}. Damage: {damage_to_poly:.2f}. Remaining Life: {colliding_poly_object.life:.2f}")
                        
                        if colliding_poly_object.life <= 0 and colliding_poly_object.in_space:
                            # Remove the polygon if destroyed
                            space.remove(colliding_poly_object.shape, colliding_poly_object.body)
                            colliding_poly_object.in_space = False
                            if colliding_poly_object in columns: columns.remove(colliding_poly_object)
                            elif colliding_poly_object in beams: beams.remove(colliding_poly_object)
                            elif colliding_poly_object in circles: circles.remove(colliding_poly_object)
                            elif colliding_poly_object in triangles: triangles.remove(colliding_poly_object)
                            # Play material break sound
                            if sound_on: # No need to check for is_explosive here, as that's handled by specific ability logic
                                if colliding_poly_object.material_type == "wood" and wood_break_sounds_list:
                                    random.choice(wood_break_sounds_list).play()
                                elif colliding_poly_object.material_type == "stone" and stone_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                                elif colliding_poly_object.material_type == "glass" and glass_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                            score += POLY_DESTROY_SCORE
                    
                    # Part 2: Damage TO THE PIG from the Polygon (Existing logic: fixed damage)
                    # This part remains as per the original code, as the request was about damage taken by the polygon.
                    generic_poly_damage_to_pig = 80 # Fixed damage from polygon to pig
                    actual_pig_instance.life -= generic_poly_damage_to_pig
                    # The print for this is less specific, so it's commented out to avoid log spam if other pig damage sources also print.
                    # print(f"DEBUG: Polygon hit Pig. Fixed Damage: {generic_poly_damage_to_pig}. Pig Remaining Life: {actual_pig_instance.life:.2f}")
                    if actual_pig_instance.life <= 0 and actual_pig_instance not in pig_to_remove:
                            # Add impact visual for pig-poly KO if impulse was significant
                            if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and \
                                arbiter.contact_point_set.points:
                                contact_point_world = arbiter.contact_point_set.points[0].point_a
                                impact_visual = ch.Explosion(
                                    center_pos_world=contact_point_world,
                                    frame_folder_path=IMPACT_FRAME_FOLDER,
                                    frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                                    scale_factor_tuple_px=IMPACT_SCALE_PX,
                                    to_pygame_func=to_pygame
                                )
                                active_explosions.add(impact_visual)

                                # pig_to_remove is defined at the beginning of post_solve_pig_wood
                                pig_to_remove.append(actual_pig_instance)
                                score += PIG_KO_SCORE # Standard pig KO score

        
        # Common removal for pigs damaged in any of the above scenarios
        for pig_obj in pig_to_remove: # pig_to_remove now contains Pig objects
            if pig_obj in pigs: # Check if it's still in the main list
                space.remove(pig_obj.shape, pig_obj.body)
                pigs.remove(pig_obj)

    def post_solve_bird_ground(arbiter, space, _):
        global birds # Access the list of active bird instances
        
        # Determine which shape is the bird (type 0) and which is the ground (type 3)
        bird_shape, ground_shape = arbiter.shapes
        if bird_shape.collision_type != 0: # Ensure shape_a is the bird
            bird_shape, ground_shape = ground_shape, bird_shape # Swap them
        
        if bird_shape.collision_type == 0 and ground_shape.collision_type == 3:
            colliding_bird_instance = None
            # Corrected loop to find the bird instance by iterating 'birds'
            for b_instance in birds: # Iterate through the actual bird instances
                if b_instance.shape == bird_shape:
                    colliding_bird_instance = b_instance
                    break
            
            if colliding_bird_instance:
                # Check if the ground shape's body is part of the static floor lines
                for ground_line in floor.static_lines:
                    if ground_line.body == ground_shape.body:
                        impact_velocity_reduction_threshold = 3000 # Threshold for hard hit
                        velocity_reduction_factor = 0.3 # How much to slow down
                        if arbiter.total_impulse.length > impact_velocity_reduction_threshold:
                            colliding_bird_instance.body.velocity *= (1 - velocity_reduction_factor*2)
                            # Play ground collision sound for bird
                            if sound_on and ground_collision_sounds_list:
                                random.choice(ground_collision_sounds_list).play()
                        
                        # Dampen angular velocity significantly upon hitting the ground
                        angular_damping_factor = 0.995 # Keep 10% of angular velocity
                        colliding_bird_instance.body.angular_velocity *= angular_damping_factor

                        # Add impact visual for bird hitting ground
                        if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and \
                            arbiter.contact_point_set.points:
                            contact_point_world = arbiter.contact_point_set.points[0].point_a # Bird's contact point
                            impact_visual = ch.Explosion(
                                center_pos_world=contact_point_world,
                                frame_folder_path=IMPACT_FRAME_FOLDER,
                                frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                                scale_factor_tuple_px=IMPACT_SCALE_PX,
                                to_pygame_func=to_pygame
                            )
                            active_explosions.add(impact_visual)
                        colliding_bird_instance.bird_hit_ground = True
                        colliding_bird_instance.body.impulse = (0, 0) # Reset impulse to prevent further movement
                        break # Found the ground, stop checking
                
    def post_solve_pig_ground(arbiter, space, _):
        global pigs, score # Access global pigs list and score

        pig_shape, ground_shape = arbiter.shapes
        # Ensure pig_shape is actually the pig (collision type 1)
        if pig_shape.collision_type != 1:
            pig_shape, ground_shape = ground_shape, pig_shape

        # Proceed if we correctly identified a pig and ground collision
        if pig_shape.collision_type == 1 and ground_shape.collision_type == 3:
            colliding_pig_instance = None
            for p_instance in pigs:
                if p_instance.shape == pig_shape:
                    colliding_pig_instance = p_instance
                    break
            
            if colliding_pig_instance:
                # Damage pig based on impact impulse
                impulse_threshold_for_damage = 500 # Min impulse to cause damage
                damage_factor_pig_ground = 0.2  # Adjust this to control damage amount

                if arbiter.total_impulse.length > impulse_threshold_for_damage:
                    damage_to_pig = arbiter.total_impulse.length * damage_factor_pig_ground
                    colliding_pig_instance.life -= damage_to_pig
                    print(f"DEBUG: Pig hit ground. Impulse: {arbiter.total_impulse.length:.2f}, Damage: {damage_to_pig:.2f}, Remaining Life: {colliding_pig_instance.life:.2f}")

                    # Play ground collision sound for pig
                    if sound_on and ground_collision_sounds_list:
                        random.choice(ground_collision_sounds_list).play()

                    # Add impact visual for pig hitting ground
                    if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and \
                        arbiter.contact_point_set.points: # Check points exist
                        contact_point_world = arbiter.contact_point_set.points[0].point_a # Pig's contact point
                        impact_visual = ch.Explosion(
                            center_pos_world=contact_point_world,
                            frame_folder_path=IMPACT_FRAME_FOLDER,
                            frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                            scale_factor_tuple_px=IMPACT_SCALE_PX,
                            to_pygame_func=to_pygame
                        )
                        active_explosions.add(impact_visual)

                    if colliding_pig_instance.life <= 0:
                        if colliding_pig_instance in pigs: # Check if not already removed
                            space.remove(colliding_pig_instance.shape, colliding_pig_instance.body)
                            pigs.remove(colliding_pig_instance)
                            score += PIG_KO_SCORE # Or a specific score for ground impact KO

    def post_solve_pig_pig(arbiter, space, _):
        global pigs, score

        shape_a, shape_b = arbiter.shapes

        pig_a_instance = None
        pig_b_instance = None

        for p_instance in pigs:
            if p_instance.shape == shape_a:
                pig_a_instance = p_instance
            elif p_instance.shape == shape_b:
                pig_b_instance = p_instance
            if pig_a_instance and pig_b_instance: # Found both pigs
                break
        
        if pig_a_instance and pig_b_instance:
            # Damage pigs based on impact impulse
            impulse_threshold_for_damage = 300  # Min impulse for pig-pig damage
            damage_factor_pig_pig = 0.2       # Adjust this to control damage amount

            if arbiter.total_impulse.length > impulse_threshold_for_damage:
                damage_to_pigs = arbiter.total_impulse.length * damage_factor_pig_pig
                
                pigs_to_remove_from_this_collision = []

                # Damage pig A
                pig_a_instance.life -= damage_to_pigs
                print(f"DEBUG: Pig hit Pig. Impulse: {arbiter.total_impulse.length:.2f}, Damage: {damage_to_pigs:.2f}. Pig A Life: {pig_a_instance.life:.2f}")
                if pig_a_instance.life <= 0 and pig_a_instance not in pigs_to_remove_from_this_collision:
                    pigs_to_remove_from_this_collision.append(pig_a_instance)

                # Damage pig B
                pig_b_instance.life -= damage_to_pigs
                print(f"DEBUG: Pig hit Pig. Impulse: {arbiter.total_impulse.length:.2f}, Damage: {damage_to_pigs:.2f}. Pig B Life: {pig_b_instance.life:.2f}")
                if pig_b_instance.life <= 0 and pig_b_instance not in pigs_to_remove_from_this_collision:
                    pigs_to_remove_from_this_collision.append(pig_b_instance)

                # Add impact visual for pig-pig collision
                if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and \
                    arbiter.contact_point_set.points: # Check points exist
                    contact_point_world = arbiter.contact_point_set.points[0].point_a # Contact point
                    impact_visual = ch.Explosion(
                        center_pos_world=contact_point_world,
                        frame_folder_path=IMPACT_FRAME_FOLDER,
                        frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                        scale_factor_tuple_px=IMPACT_SCALE_PX,
                        to_pygame_func=to_pygame
                    )
                    active_explosions.add(impact_visual)

                for pig_to_remove in pigs_to_remove_from_this_collision:
                    if pig_to_remove in pigs: # Check if not already removed
                        space.remove(pig_to_remove.shape, pig_to_remove.body)
                        pigs.remove(pig_to_remove)
                        score += PIG_KO_SCORE # Standard score for pig KO

    def post_solve_poly_vs_poly(arbiter, space, data):
        global columns, beams, circles, triangles, score, birds # Ensure all necessary globals are accessible

        shape_a_raw, shape_b_raw = arbiter.shapes # Use clear names for the raw shapes

        poly_a_obj = None
        poly_b_obj = None

        # Find the Polygon objects corresponding to the Pymunk shapes
        # Ability polygons (like bomb projectiles) are often stored in 'columns'
        all_polys = columns + beams + circles + triangles
        for poly in all_polys:
            if poly.shape == shape_a_raw:
                poly_a_obj = poly
            if poly.shape == shape_b_raw:
                poly_b_obj = poly
            if poly_a_obj and poly_b_obj: # Found both
                break
        
        if not poly_a_obj or not poly_b_obj:
            # One or both shapes aren't our managed Polygon objects, bail.
            return

        # --- Part 1: Handle Active Special Ability Polygons (e.g., Sahur's Bat, Bomb's Projectile) ---
        active_bird = birds[-1] if birds else None

        # Check if the active bird's ability is involved in this collision
        if active_bird and active_bird.fahigkeit_verwendet and \
            hasattr(active_bird, 'ability_polygon') and \
            active_bird.ability_polygon is not None:

            ability_poly_instance = active_bird.ability_polygon
            
            # --- Handle Bomb's Projectile Collision with another Polygon ---
            if isinstance(active_bird, ch.Bomb):
                bomb_projectile_obj = None
                other_poly_hit_by_bomb = None

                if ability_poly_instance == poly_a_obj: # poly_a_obj is the bomb projectile
                    bomb_projectile_obj = poly_a_obj
                    other_poly_hit_by_bomb = poly_b_obj
                elif ability_poly_instance == poly_b_obj: # poly_b_obj is the bomb projectile
                    bomb_projectile_obj = poly_b_obj
                    other_poly_hit_by_bomb = poly_a_obj
                
                if bomb_projectile_obj and other_poly_hit_by_bomb:
                    # Bomb projectile has directly hit another polygon
                    print(f"DEBUG: Bomb projectile directly hit {other_poly_hit_by_bomb.material_type} {other_poly_hit_by_bomb.element_type}.")
                    
                    # Trigger explosion if impulse is sufficient and both objects are valid
                    if arbiter.total_impulse.length > 10.0 and \
                        bomb_projectile_obj.in_space and other_poly_hit_by_bomb.in_space:
                        
                        explosion_center = bomb_projectile_obj.body.position
                        # IF YOU WANT DIFFERENT VALUES FOR POLY-POLY BOMB EXPLOSION, CHANGE THEM HERE:
                        explosion_radius = BOMB_PROJECTILE_EXPLOSION_RADIUS
                        explosion_base_damage_polys = 1700 # Example: 3000 if you want higher poly damage
                        explosion_base_damage_pigs = 175  # Consistent base damage for pigs

                        # Play explosion sound for Bomb's projectile
                        if sound_on and explosion_sounds_list:
                            random.choice(explosion_sounds_list).play()
                        
                        # Create visual explosion for Bomb's projectile
                        explosion_visual = ch.Explosion(
                            center_pos_world=explosion_center,
                            frame_folder_path=BOMB_EXPLOSION_FRAME_FOLDER,
                            frame_duration_ms=BOMB_EXPLOSION_FRAME_DURATION_MS,
                            scale_factor_tuple_px=BOMB_EXPLOSION_SCALE_PX,
                            to_pygame_func=to_pygame
                        )
                        active_explosions.add(explosion_visual)

                        print(f"DEBUG: Bomb exploding (poly hit poly). Center: {explosion_center}, Radius: {explosion_radius}, Poly Dmg: {explosion_base_damage_polys}, Pig Dmg: {explosion_base_damage_pigs}")

                        # Damage POLYGONS in the explosion radius
                        polys_in_explosion_to_remove_locally = []
                        # all_polys was defined earlier
                        for poly_item in all_polys:
                            if poly_item == bomb_projectile_obj: continue # Bomb doesn't damage itself
                            
                            if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue 

                            dist_vec = poly_item.body.position - explosion_center
                            distance = dist_vec.length
                            if distance < explosion_radius:
                                damage_falloff_factor = max(0, (explosion_radius - distance) / explosion_radius)
                                actual_damage = explosion_base_damage_polys * damage_falloff_factor
                                
                                poly_item.life -= actual_damage
                                print(f"DEBUG: Bomb explosion hit {poly_item.material_type} {poly_item.element_type}. Damage: {actual_damage:.2f}. Remaining Life: {poly_item.life:.2f}")
                                if poly_item.life <= 0 and poly_item not in polys_in_explosion_to_remove_locally:
                                    polys_in_explosion_to_remove_locally.append(poly_item)
                                    score += POLY_DESTROY_SCORE 
                        
                        # Apply KNOCKBACK to POLYGONS from Bomb Explosion
                        for poly_item in all_polys: # all_polys was defined earlier
                            if poly_item == bomb_projectile_obj: continue
                            if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue

                            dist_vec_knockback = poly_item.body.position - explosion_center
                            distance_knockback = dist_vec_knockback.length
                            if distance_knockback < explosion_radius and distance_knockback > 0:
                                knockback_dir = dist_vec_knockback.normalized()
                                falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                                knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                                poly_item.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))
                                print(f"DEBUG: Bomb explosion (poly hit poly) knockback on {poly_item.material_type} {poly_item.element_type}. Impulse: {knockback_impulse_magnitude:.2f}")

                        # Apply KNOCKBACK to PIGS from Bomb Explosion
                        for pig_item in pigs:
                            if not pig_item.body or pig_item.body.body_type == pm.Body.STATIC: continue

                            dist_vec_knockback = pig_item.body.position - explosion_center
                            distance_knockback = dist_vec_knockback.length
                            if distance_knockback < explosion_radius and distance_knockback > 0:
                                knockback_dir = dist_vec_knockback.normalized()
                                falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                                knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                                pig_item.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))
                                print(f"DEBUG: Bomb explosion (poly hit poly) knockback on Pig. Impulse: {knockback_impulse_magnitude:.2f}")



                        
                        # Remove polygons destroyed by this explosion
                        for poly_to_destroy in polys_in_explosion_to_remove_locally:
                            if poly_to_destroy.in_space: # Check again before removal
                                space.remove(poly_to_destroy.shape, poly_to_destroy.body)
                                poly_to_destroy.in_space = False
                                if poly_to_destroy in columns: columns.remove(poly_to_destroy)
                                elif poly_to_destroy in beams: beams.remove(poly_to_destroy)
                                elif poly_to_destroy in circles: circles.remove(poly_to_destroy)
                                elif poly_to_destroy in triangles: triangles.remove(poly_to_destroy)
                        
                        # 4. Remove the bomb projectile itself after explosion
                        if bomb_projectile_obj.in_space: # Check it wasn't already removed
                            space.remove(bomb_projectile_obj.shape, bomb_projectile_obj.body)
                            bomb_projectile_obj.in_space = False
                            if bomb_projectile_obj in columns: # Bomb projectiles are added to columns
                                columns.remove(bomb_projectile_obj)
                            # Nullify the bird's reference to this ability polygon
                            if hasattr(active_bird, 'ability_polygon') and active_bird.ability_polygon == bomb_projectile_obj:
                                active_bird.ability_polygon = None
                
            elif isinstance(active_bird, ch.Patapim): # Patapim's Potion collision with another Polygon
                potion_projectile_obj = None
                other_poly_hit_by_potion = None

                if ability_poly_instance == poly_a_obj:
                    potion_projectile_obj = poly_a_obj
                    other_poly_hit_by_potion = poly_b_obj
                elif ability_poly_instance == poly_b_obj:
                    potion_projectile_obj = poly_b_obj
                    other_poly_hit_by_potion = poly_a_obj
                
                if potion_projectile_obj and other_poly_hit_by_potion:
                    # Ensure the "other" is not the potion itself, though ability_poly_instance should handle this
                    if other_poly_hit_by_potion != potion_projectile_obj:
                        print(f"DEBUG: Patapim potion hit {other_poly_hit_by_potion.material_type} {other_poly_hit_by_potion.element_type}. Removing potion, no explosion.")
                    
                    # Condition for removal (impact and potion exists)
                    if arbiter.total_impulse.length > 10.0 and \
                        potion_projectile_obj.in_space: # Only need to check potion_projectile_obj.in_space for its own removal
                        
                        if sound_on:
                            # Play sound before applying effect
                            potion_break_sound.play()
                        # --- EXPLOSION LOGIC REMOVED ---
                        # The potion will just be removed without AoE effects.
                        
                        # Remove the potion projectile
                        if potion_projectile_obj.in_space: # Double check
                            potion_impact_position = potion_projectile_obj.body.position
                            apply_potion_antigravity(potion_impact_position, space) # Apply effect

                            space.remove(potion_projectile_obj.shape, potion_projectile_obj.body)
                            potion_projectile_obj.in_space = False
                            if potion_projectile_obj in columns: columns.remove(potion_projectile_obj)
                            # Use the stored owner_bird to clear the ability_polygon reference
                            if hasattr(potion_projectile_obj, 'owner_bird') and potion_projectile_obj.owner_bird:
                                if getattr(potion_projectile_obj.owner_bird, 'ability_polygon', None) == potion_projectile_obj:
                                    potion_projectile_obj.owner_bird.ability_polygon = None
                        return # Potion collision handled (it's removed)

            elif isinstance(active_bird, ch.Sahur): # Sahur's Bat collision with another Polygon
                sahurs_bat_poly_obj = None
                other_poly_hit_by_bat = None

                # Check if the ability_poly_instance (Sahur's bat) is one of the colliding polys
                if ability_poly_instance == poly_a_obj: # poly_a_obj is Sahur's bat
                    sahurs_bat_poly_obj = poly_a_obj
                    other_poly_hit_by_bat = poly_b_obj
                elif ability_poly_instance == poly_b_obj: # poly_b_obj is Sahur's bat
                    sahurs_bat_poly_obj = poly_b_obj
                    other_poly_hit_by_bat = poly_a_obj
                
                if sahurs_bat_poly_obj and other_poly_hit_by_bat:
                    # Sahur's bat has hit another polygon (handled by specific bird logic)
                    # Ensure the bat itself is not the target, the target is a destructible polygon, and it's dynamic
                    if other_poly_hit_by_bat.element_type != "bats" and \
                        other_poly_hit_by_bat.in_space and \
                        other_poly_hit_by_bat.body.body_type == pm.Body.DYNAMIC:
                        
                        # Minimal impulse for bat to register hit on polygon
                        if arbiter.total_impulse.length > 1.0: # Very low threshold, bat is powerful
                            sahurs_bat_damage_to_polygons = 200000 # Consistent high damage as with pigs
                            
                            print(f"DEBUG: Sahur's bat hit {other_poly_hit_by_bat.material_type} {other_poly_hit_by_bat.element_type}. Damage: {sahurs_bat_damage_to_polygons}")
                            other_poly_hit_by_bat.life -= sahurs_bat_damage_to_polygons
                            
                            if other_poly_hit_by_bat.life <= 0:
                                if other_poly_hit_by_bat.in_space: # Check again before removal
                                    space.remove(other_poly_hit_by_bat.shape, other_poly_hit_by_bat.body)
                                    other_poly_hit_by_bat.in_space = False
                                    if other_poly_hit_by_bat in columns: columns.remove(other_poly_hit_by_bat)
                                    elif other_poly_hit_by_bat in beams: beams.remove(other_poly_hit_by_bat)
                                    elif other_poly_hit_by_bat in circles: circles.remove(other_poly_hit_by_bat)
                                    elif other_poly_hit_by_bat in triangles: triangles.remove(other_poly_hit_by_bat)
                                    # Play material break sound for polygon destroyed by bat
                                    if sound_on:
                                        if other_poly_hit_by_bat.material_type == "wood" and wood_break_sounds_list:
                                            random.choice(wood_break_sounds_list).play()
                                        elif other_poly_hit_by_bat.material_type == "stone" and stone_break_sounds_list:
                                            random.choice(stone_break_sounds_list).play()
                                        elif other_poly_hit_by_bat.material_type == "glass" and glass_break_sounds_list:
                                            random.choice(glass_break_sounds_list).play()

                                    score += POLY_DESTROY_SCORE
                        return # Sahur's bat collision handled for this pair
            # The redundant re-finding of poly_a_obj, poly_b_obj and the subsequent
            # generic `if active_ability_item:` block has been removed.
            # The specific handlers for Bomb, Patapim, and Sahur (when they are the active_bird)
            # are more precise and already `return`, preventing fall-through to this point
            # for collisions involving the *current* bird's active ability polygon.
            # If this point is reached, it's a general polygon-polygon collision,
            # or a collision involving an old/inactive ability item.

                # --- Part 2: Handle General Polygon-on-Polygon Collisions ---
                # This part executes if NEITHER poly_a_obj nor poly_b_obj is an ACTIVE ability item of the LATEST bird.
                elements_to_remove_from_general_collision = []
                impulse_strength = arbiter.total_impulse.length

                # Damage poly_a_obj if it's dynamic, not "bats", and impulse is high enough
                if poly_a_obj.body.body_type == pm.Body.DYNAMIC and poly_a_obj.element_type != "bats" and impulse_strength > POLY_POLY_COLLISION_IMPULSE_THRESHOLD:
                    poly_a_obj.life -= POLY_POLY_DAMAGE_VALUE
                    print(f"DEBUG: Poly-Poly hit {poly_a_obj.material_type} {poly_a_obj.element_type} (A). Damage: {POLY_POLY_DAMAGE_VALUE}. Remaining Life: {poly_a_obj.life:.2f}")
                    if poly_a_obj.life <= 0 and poly_a_obj.in_space and poly_a_obj not in elements_to_remove_from_general_collision:
                        elements_to_remove_from_general_collision.append(poly_a_obj)
                        score += POLY_DESTROY_SCORE
                        # Play material break sound if not an exploding crate about to explode
                        if not (poly_a_obj.is_explosive and not poly_a_obj.has_exploded):
                            if sound_on:
                                if poly_a_obj.material_type == "wood" and wood_break_sounds_list:
                                    random.choice(wood_break_sounds_list).play()
                                elif poly_a_obj.material_type == "stone" and stone_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                                elif poly_a_obj.material_type == "glass" and glass_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                    # Check if poly_a_obj is an exploding crate and should explode
                    if poly_a_obj.is_explosive and not poly_a_obj.has_exploded and poly_a_obj.life <= 0:
                        trigger_custom_polygon_explosion(
                            exploding_poly=poly_a_obj, space_ref=space, pigs_list=pigs,
                            all_destructible_polys_list=columns + beams + circles + triangles,
                            active_explosions_group=active_explosions,
                            to_pygame_func=to_pygame, sound_on_flag=sound_on,
                            explosion_sounds_list_ref=explosion_sounds_list
                        )
                        if poly_a_obj in elements_to_remove_from_general_collision:
                            elements_to_remove_from_general_collision.remove(poly_a_obj)
                        
                # Damage poly_b_obj if it's dynamic, not "bats", and impulse is high enough
                if poly_b_obj.body.body_type == pm.Body.DYNAMIC and poly_b_obj.element_type != "bats" and impulse_strength > POLY_POLY_COLLISION_IMPULSE_THRESHOLD:
                    poly_b_obj.life -= POLY_POLY_DAMAGE_VALUE
                    print(f"DEBUG: Poly-Poly hit {poly_b_obj.material_type} {poly_b_obj.element_type} (B). Damage: {POLY_POLY_DAMAGE_VALUE}. Remaining Life: {poly_b_obj.life:.2f}")
                    if poly_b_obj.life <= 0 and poly_b_obj.in_space and poly_b_obj not in elements_to_remove_from_general_collision:
                        elements_to_remove_from_general_collision.append(poly_b_obj)
                        score += POLY_DESTROY_SCORE
                        # Play material break sound if not an exploding crate about to explode
                        if not (poly_b_obj.is_explosive and not poly_b_obj.has_exploded):
                            if sound_on:
                                if poly_b_obj.material_type == "wood" and wood_break_sounds_list:
                                    random.choice(wood_break_sounds_list).play()
                                elif poly_b_obj.material_type == "stone" and stone_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                                elif poly_b_obj.material_type == "glass" and glass_break_sounds_list:
                                    random.choice(stone_break_sounds_list).play()
                    if poly_b_obj.is_explosive and not poly_b_obj.has_exploded and poly_b_obj.life <= 0:
                        trigger_custom_polygon_explosion(
                            exploding_poly=poly_b_obj, space_ref=space, pigs_list=pigs,
                            all_destructible_polys_list=columns + beams + circles + triangles,
                            active_explosions_group=active_explosions,
                            to_pygame_func=to_pygame, sound_on_flag=sound_on,
                            explosion_sounds_list_ref=explosion_sounds_list
                        )
                        if poly_b_obj in elements_to_remove_from_general_collision:
                            elements_to_remove_from_general_collision.remove(poly_b_obj)



                # Add impact visual for general poly-poly collision if impulse is high enough
                # Use MIN_IMPULSE_FOR_IMPACT_VISUAL for consistency
                if impulse_strength > MIN_IMPULSE_FOR_IMPACT_VISUAL and arbiter.contact_point_set.points:
                    # Check if this collision wasn't already handled by a bomb/potion explosion visual
                    # This is a simple check; more robust would be to flag if an explosion was already created for this arbiter
                    if not (isinstance(active_bird, ch.Bomb) and bomb_projectile_obj) and \
                        not (isinstance(active_bird, ch.Patapim) and potion_projectile_obj):
                        contact_point_world = arbiter.contact_point_set.points[0].point_a
                        impact_visual = ch.Explosion(
                            center_pos_world=contact_point_world,
                            frame_folder_path=IMPACT_FRAME_FOLDER,
                            frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                            scale_factor_tuple_px=IMPACT_SCALE_PX,
                            to_pygame_func=to_pygame)
                        active_explosions.add(impact_visual)
                for element in elements_to_remove_from_general_collision:
                    if element.in_space: # Check again before removal
                        # If it's an explosive that already exploded, it's already out of space.
                        if not (element.is_explosive and element.has_exploded):
                            space.remove(element.shape, element.body)
                            element.in_space = False
                            if element in columns: columns.remove(element)
                            elif element in beams: beams.remove(element)
                            elif element in circles: circles.remove(element)
                            elif element in triangles: triangles.remove(element)

    def post_solve_poly_ground(arbiter, space, data):
        global columns, beams, circles, triangles, score, birds, pigs

        # Identify which shape is the polygon (type 2) and which is the ground (type 3)
        poly_shape, ground_shape = arbiter.shapes
        if poly_shape.collision_type != 2: # Ensure poly_shape is the polygon
            poly_shape, ground_shape = ground_shape, poly_shape

        if not (poly_shape.collision_type == 2 and ground_shape.collision_type == 3):
            return # Not a polygon-ground collision

        colliding_poly_object = None
        all_destructible_polys = columns + beams + circles + triangles
        for poly_item in all_destructible_polys:
            if poly_item.shape == poly_shape:
                colliding_poly_object = poly_item
                break
        
        if not colliding_poly_object or not colliding_poly_object.in_space:
            return

        # --- Check if it's an active Bomb projectile hitting the ground ---
        active_bird = birds[-1] if birds else None
        if active_bird and (isinstance(active_bird, ch.Bomb) or isinstance(active_bird, ch.Patapim)) and \
            active_bird.fahigkeit_verwendet and \
            hasattr(active_bird, 'ability_polygon') and \
            active_bird.ability_polygon == colliding_poly_object:
            
            ability_projectile_obj = colliding_poly_object # Could be Bomb or Potion

            if isinstance(active_bird, ch.Bomb):
                bomb_projectile_obj = ability_projectile_obj
                # Trigger explosion if impulse is sufficient
                if arbiter.total_impulse.length > 10.0: # Low impulse threshold for explosion on ground
                    print(f"DEBUG: Bomb projectile hit ground. Impulse: {arbiter.total_impulse.length:.2f}. Exploding.")
                    
                    explosion_center = bomb_projectile_obj.body.position
                    explosion_radius = BOMB_PROJECTILE_EXPLOSION_RADIUS
                    explosion_base_damage_polys = 1700
                    explosion_base_damage_pigs = 175

                    # Play explosion sound for Bomb's projectile hitting ground (using bird ability sounds)
                    if sound_on and bird_ability_explosion_sounds_list:
                        random.choice(bird_ability_explosion_sounds_list).play()
                    
                    # Create visual explosion for Bomb's projectile hitting ground
                    explosion_visual = ch.Explosion(
                        center_pos_world=explosion_center,
                        frame_folder_path=BOMB_EXPLOSION_FRAME_FOLDER,
                        frame_duration_ms=BOMB_EXPLOSION_FRAME_DURATION_MS,
                        scale_factor_tuple_px=BOMB_EXPLOSION_SCALE_PX,
                        to_pygame_func=to_pygame
                    )
                    active_explosions.add(explosion_visual)

                    # Damage POLYGONS in the explosion radius
                    polys_in_explosion_to_remove_locally = []
                    for poly_item in all_destructible_polys:
                        if poly_item == bomb_projectile_obj: continue
                        if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue
                        dist_vec = poly_item.body.position - explosion_center
                        distance = dist_vec.length
                        if distance < explosion_radius:
                            damage_falloff_factor = max(0, (explosion_radius - distance) / explosion_radius)
                            actual_damage = explosion_base_damage_polys * damage_falloff_factor
                            poly_item.life -= actual_damage
                            if poly_item.life <= 0 and poly_item not in polys_in_explosion_to_remove_locally:
                                polys_in_explosion_to_remove_locally.append(poly_item)
                                score += POLY_DESTROY_SCORE # Global score
                                # Play material break sound if not an exploding crate that just exploded
                                if not (poly_item.is_explosive and poly_item.has_exploded):
                                    if sound_on:
                                        if poly_item.material_type == "wood" and wood_break_sounds_list:
                                            random.choice(wood_break_sounds_list).play()
                                        elif poly_item.material_type == "stone" and stone_break_sounds_list:
                                            random.choice(stone_break_sounds_list).play()
                                    elif poly_item.material_type == "glass" and glass_break_sounds_list:
                                        random.choice(glass_break_sounds_list).play()

                    # Apply KNOCKBACK to POLYGONS from Bomb Ground Explosion
                    for poly_item in all_destructible_polys:
                        if poly_item == bomb_projectile_obj: continue
                        if not poly_item.in_space or poly_item.body.body_type == pm.Body.STATIC: continue
                        dist_vec_knockback = poly_item.body.position - explosion_center
                        distance_knockback = dist_vec_knockback.length
                        if distance_knockback < explosion_radius and distance_knockback > 0:
                            knockback_dir = dist_vec_knockback.normalized()
                            falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                            knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                            poly_item.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))
                    
                    # Damage PIGS in the explosion radius
                    pigs_in_explosion_to_remove_locally = []
                    for pig_item in pigs: 
                        if not pig_item.body or not pig_item.shape: continue
                        dist_vec = pig_item.body.position - explosion_center
                        distance = dist_vec.length
                        if distance < explosion_radius:
                            damage_falloff_factor = max(0, (explosion_radius - distance) / explosion_radius)
                            actual_damage = explosion_base_damage_pigs * damage_falloff_factor
                            pig_item.life -= actual_damage
                            if pig_item.life <= 0 and pig_item not in pigs_in_explosion_to_remove_locally:
                                pigs_in_explosion_to_remove_locally.append(pig_item)
                                score += PIG_KO_SCORE

                    # Apply KNOCKBACK to PIGS from Bomb Ground Explosion
                    for pig_item in pigs:
                        if not pig_item.body or pig_item.body.body_type == pm.Body.STATIC: continue
                        dist_vec_knockback = pig_item.body.position - explosion_center
                        distance_knockback = dist_vec_knockback.length
                        if distance_knockback < explosion_radius and distance_knockback > 0:
                            knockback_dir = dist_vec_knockback.normalized()
                            falloff_multiplier = max(0, (explosion_radius - distance_knockback) / explosion_radius)
                            knockback_impulse_magnitude = BOMB_EXPLOSION_KNOCKBACK_BASE * falloff_multiplier
                            pig_item.body.apply_impulse_at_local_point(knockback_dir * knockback_impulse_magnitude, (0,0))

                    # Remove destroyed polygons and pigs
                    for poly_to_destroy in polys_in_explosion_to_remove_locally:
                        if poly_to_destroy.in_space:
                            space.remove(poly_to_destroy.shape, poly_to_destroy.body)
                            poly_to_destroy.in_space = False
                            if poly_to_destroy in columns: columns.remove(poly_to_destroy)
                            elif poly_to_destroy in beams: beams.remove(poly_to_destroy)
                            elif poly_to_destroy in circles: circles.remove(poly_to_destroy)
                            elif poly_to_destroy in triangles: triangles.remove(poly_to_destroy)
                    for pig_to_destroy in pigs_in_explosion_to_remove_locally:
                        if pig_to_destroy in pigs:
                            space.remove(pig_to_destroy.shape, pig_to_destroy.body)
                            pigs.remove(pig_to_destroy)
                    
                    # Remove the bomb projectile
                    if bomb_projectile_obj.in_space:
                        space.remove(bomb_projectile_obj.shape, bomb_projectile_obj.body)
                        bomb_projectile_obj.in_space = False
                        if bomb_projectile_obj in columns: columns.remove(bomb_projectile_obj)
                        if hasattr(active_bird, 'ability_polygon') and active_bird.ability_polygon == bomb_projectile_obj:
                            active_bird.ability_polygon = None
                    return # Bomb explosion handled

            elif isinstance(active_bird, ch.Patapim):
                potion_obj = ability_projectile_obj
                if arbiter.total_impulse.length > 10.0 and potion_obj.in_space: # Potion hit ground
                    print(f"DEBUG: Patapim's potion hit ground. Impulse: {arbiter.total_impulse.length:.2f}. Removing potion, no explosion.")
                    # Play sound before applying effect
                    if sound_on:
                        potion_break_sound.play()
                    
                    # --- EXPLOSION LOGIC REMOVED ---
                    # The potion will just be removed without AoE effects.

                    potion_impact_position = potion_obj.body.position
                    apply_potion_antigravity(potion_impact_position, space) # Apply effect

                    # Remove the potion itself
                    if potion_obj.in_space: # Double check
                        space.remove(potion_obj.shape, potion_obj.body)
                        potion_obj.in_space = False
                        if potion_obj in columns: columns.remove(potion_obj)
                        # Use the stored owner_bird to clear the ability_polygon reference
                        if hasattr(potion_obj, 'owner_bird') and potion_obj.owner_bird:
                            if getattr(potion_obj.owner_bird, 'ability_polygon', None) == potion_obj:
                                potion_obj.owner_bird.ability_polygon = None
                    return # Potion removal handled

        # --- If not an exploding bomb, proceed with generic polygon-ground collision damage ---
        if colliding_poly_object.body.body_type == pm.Body.DYNAMIC and \
            colliding_poly_object.element_type != "bats" and \
            colliding_poly_object.element_type != "bombs": # Also ensure it's not a bomb projectile that didn't meet explosion criteria
            # This is the original logic for regular polygons hitting the ground
            
            impulse_strength = arbiter.total_impulse.length
            if impulse_strength > POLY_GROUND_IMPULSE_THRESHOLD:
                damage_to_poly = impulse_strength * POLY_GROUND_DAMAGE_FACTOR
                colliding_poly_object.life -= damage_to_poly
                print(f"DEBUG: {colliding_poly_object.material_type} {colliding_poly_object.element_type} hit ground. Impulse: {impulse_strength:.2f}, Damage: {damage_to_poly:.2f}, Remaining Life: {colliding_poly_object.life:.2f}")

                # Play ground collision sound for polygon
                # Check if this element is an exploding crate and should explode
                if colliding_poly_object.is_explosive and not colliding_poly_object.has_exploded and colliding_poly_object.life <= 0:
                    trigger_custom_polygon_explosion(
                        exploding_poly=colliding_poly_object, space_ref=space, pigs_list=pigs,
                        all_destructible_polys_list=columns + beams + circles + triangles,
                        active_explosions_group=active_explosions,
                        to_pygame_func=to_pygame, sound_on_flag=sound_on,
                        explosion_sounds_list_ref=explosion_sounds_list
                    )
                    if colliding_poly_object in columns: columns.remove(colliding_poly_object)
                    elif colliding_poly_object in beams: beams.remove(colliding_poly_object) # Add similar checks
                    elif colliding_poly_object in circles: circles.remove(colliding_poly_object)
                    elif colliding_poly_object in triangles: triangles.remove(colliding_poly_object)
                    return # Explosion handled, no further processing for this polygon needed

                if sound_on and ground_collision_sounds_list:
                    random.choice(ground_collision_sounds_list).play()

                if colliding_poly_object.life <= 0 and colliding_poly_object.in_space:
                    # Remove the polygon if destroyed
                    space.remove(colliding_poly_object.shape, colliding_poly_object.body)
                    colliding_poly_object.in_space = False
                    if colliding_poly_object in columns: columns.remove(colliding_poly_object)
                    elif colliding_poly_object in beams: beams.remove(colliding_poly_object)
                    elif colliding_poly_object in circles: circles.remove(colliding_poly_object)
                    elif colliding_poly_object in triangles: triangles.remove(colliding_poly_object)
                    score += POLY_DESTROY_SCORE # Global score
                    # Play material break sound for polygon destroyed by ground impact
                    # No need to check for is_explosive here, as that's handled by its own trigger
                    if sound_on:
                        if colliding_poly_object.material_type == "wood" and wood_break_sounds_list:
                            random.choice(wood_break_sounds_list).play()
                        elif colliding_poly_object.material_type == "stone" and stone_break_sounds_list:
                            random.choice(stone_break_sounds_list).play()
                        elif colliding_poly_object.material_type == "glass" and glass_break_sounds_list:
                            random.choice(stone_break_sounds_list).play()
                    
                    # Add impact visual for polygon hitting ground
                    if arbiter.total_impulse.length > MIN_IMPULSE_FOR_IMPACT_VISUAL and arbiter.contact_point_set.points: # Ensure contact points exist
                        contact_point_world = arbiter.contact_point_set.points[0].point_a
                        impact_visual = ch.Explosion(
                            center_pos_world=contact_point_world,
                            frame_folder_path=IMPACT_FRAME_FOLDER,
                            frame_duration_ms=IMPACT_FRAME_DURATION_MS,
                            scale_factor_tuple_px=IMPACT_SCALE_PX,
                            to_pygame_func=to_pygame
                        )
                        active_explosions.add(impact_visual)


    space.add_collision_handler(0, 1).post_solve = post_solve_bird_pig
    space.add_collision_handler(0, 2).post_solve = post_solve_bird_wood 
    space.add_collision_handler(1, 2).post_solve = post_solve_pig_wood
    space.add_collision_handler(0, 3).post_solve = post_solve_bird_ground
    space.add_collision_handler(2, 2).post_solve = post_solve_poly_vs_poly # Polygon vs Polygon
    space.add_collision_handler(1, 1).post_solve = post_solve_pig_pig # Pig (1) vs Pig (1)
    space.add_collision_handler(1, 3).post_solve = post_solve_pig_ground
    space.add_collision_handler(2, 3).post_solve = post_solve_poly_ground

    t1 = 0
    c = 0
    menu_open = False
    menu_open_time = 0
    menu_click_delay = 0.2  # seconds

    # game states:
    # 0:running
    # 5:paused
    # 3:lose
    # 4:win
    # 6:levels menu
    # Create and load the first level with the correct arguments
    level = Level(pigs, columns, beams, circles, triangles, space, screen_height, screen_width)
    level.load_level()
    floor.build_lines(loch_extent_x=level.loch_extent_x)

    def get_next_bird(mouse_distance, launch_angle, bird_x, bird_y, space, level, impulse_factor_to_pass):
        global bird
        if len(level.level_birds) > 0 :
            bird = level.level_birds[-1]
            if bird == "sahur":
                bird = ch.Sahur(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = sahur_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 3500
            elif bird == "liri":
                bird = ch.Liri(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = liri_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 1300
            elif bird == "palocleves":
                bird = ch.Palocleves(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = palocleves_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 2900
            elif bird == "trala":
                bird = ch.Trala(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = trala_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 3000
            elif bird == "glorbo":
                bird = ch.Glorbo(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = glorbo_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 3000
            elif bird == "patapim":
                bird = ch.Patapim(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = patapim_sound
                dur = 3000
            elif bird == "bomb":
                bird = ch.Bomb(mouse_distance, launch_angle, bird_x, bird_y, space, screen_height, screen_width, level, impulse_factor_to_pass)
                bird_sound = bomb_sound # Play for a maximum of 3000ms (3 seconds)
                dur = 2000
            
            if sound_on and bird_sound:
                bird_sound.play(maxtime=dur)
            return bird

    def get_next_bird_img():
        pass

    def handle_resize(event):
        global slingl_scaled_width
        global slingr
        global slingl
        global slingl_scaled_height
        global slingr_scaled_width
        global slingr_scaled_height
        global levels_drawn
        global screen, screen_width, screen_height, scale_x, scale_y, base_width, base_height # Changed to global
        # slingl, slingr are global, will be modified

        # Re-initialize in resizable mode with event dimensions
        screen = pg.display.set_mode((event.w, event.h), pg.RESIZABLE)
        
        # Update global screen dimensions and scaling factors
        screen_width, screen_height = event.w, event.h
        
        scale_x = screen_width / base_width
        scale_y = screen_height / base_height

        # Redraw the screen immediately after resize
        screen.fill((130, 200, 100)) # Or your bg color
        bg_scaled = pg.transform.scale(bg, (screen_width, screen_height))
        screen.blit(bg_scaled, (0, 0))

        # Rescale sling images using their current scaled design dimensions
        # These are the *design* dimensions, scale_size will apply current screen scaling
        slingl=pg.transform.scale(slingl, scale_size(slingl_scaled_width, slingl_scaled_height))
        slingr=pg.transform.scale(slingr, scale_size(slingr_scaled_width, slingr_scaled_height))
        # If in levels menu, need to redraw it
        if game_state == 6:
            levels_drawn = False
            draw_levels()
        pg.display.flip()

    while running:
            
            # Background Music Logic
            if game_state in [5, 6, 7]:  # Menu states (Pause, Levels, Main Menu)
                if sound_on and not pg.mixer.music.get_busy():
                    pg.mixer.music.play(-1)  # Play looped
                elif not sound_on and pg.mixer.music.get_busy():
                    pg.mixer.music.stop()
            else:  # Gameplay or other states (Win/Lose screens will also stop music here)
                if pg.mixer.music.get_busy():
                    pg.mixer.music.stop()


            mouse_button_down = False  # Track if mouse button is pressed this frame

            # Calculate the correct collision rectangle for the stop/pause button based on current scaling
            # stop_button is a 65x65 surface before this frame's scaling for blit
            current_stop_button_width = int(65 * scale_x) 
            current_stop_button_height = int(65 * scale_y)
            current_stop_button_pos = scale_pos(8,8)
            final_stop_button_rect = pg.Rect(current_stop_button_pos[0], current_stop_button_pos[1], current_stop_button_width, current_stop_button_height)
            

            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False
                elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                    running = False
                elif event.type == pg.VIDEORESIZE:
                    handle_resize(event)
                elif game_state == 0:
                    if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                        mouse_button_down = True 
                        x_mouse_down, y_mouse_down = event.pos

                        can_patapim_aim = False
                        if birds:
                            active_bird_check = birds[-1]
                            if isinstance(active_bird_check, ch.Patapim) and \
                            not active_bird_check.fahigkeit_verwendet and \
                            not final_stop_button_rect.collidepoint(x_mouse_down, y_mouse_down):
                                
                                time_since_resume_check = time.time() - last_resume_time
                                cooldown_passed_check = time_since_resume_check >= 0.2 # Shorter cooldown for aiming start
                                
                                in_sling_area = (110 * scale_x < x_mouse_down < 170 * scale_x and \
                                                250 * scale_y < y_mouse_down < 400 * scale_y)

                                if cooldown_passed_check and not in_sling_area:
                                    can_patapim_aim = True

                        if can_patapim_aim:
                            active_bird = birds[-1] 
                            patapim_is_aiming_potion = True
                            active_bird.fahigkeit_verwendet = True 
                            patapim_slowdown_active = True
                            patapim_slowdown_start_time = time.time()
                            current_slowdown_factor = 0.3 # Slowdown for aiming
                            if sound_on:
                                patapim_throw_ability_sound.play() # Sound for starting aim
                            mouse_pressed_to_shoot = False 
                        
                        elif (110 * scale_x < x_mouse_down < 170 * scale_x and \
                            250 * scale_y < y_mouse_down < 400 * scale_y) and \
                            level.number_of_birds > 0: 
                            mouse_pressed_to_shoot = True
                            patapim_is_aiming_potion = False 

                    elif event.type == pg.MOUSEBUTTONUP and event.button == 1:
                        mouse_button_down = False
                        if game_just_resumed:
                            game_just_resumed = False # Reset flag for subsequent inputs
                            # This click was to resume, so skip all other MOUSEBUTTONUP logic 
                            # in game_state 0 for this specific event.
                            continue

                        x_mouse_up, y_mouse_up = event.pos # Capture mouse up position

                        if patapim_is_aiming_potion and birds and isinstance(birds[-1], ch.Patapim):
                            patapim_is_aiming_potion = False
                            patapim_slowdown_active = False
                            current_slowdown_factor = 1.0
                            patapim_aim_trajectory_points.clear()

                            active_bird = birds[-1]
                            
                            # Potion shoots from bird's current Pymunk world position towards mouse release Pymunk world position
                            bird_world_pos = active_bird.body.position
                            # x_mouse_up, y_mouse_up are screen coordinates from the event
                            mouse_world_pos_up = screen_to_world(x_mouse_up, y_mouse_up, screen_height, scale_x, scale_y)

                            delta_x_world = mouse_world_pos_up.x - bird_world_pos.x
                            delta_y_world = mouse_world_pos_up.y - bird_world_pos.y

                            potion_launch_angle_rad = math.atan2(delta_y_world, delta_x_world)
                            
                            # Call Patapim's method to launch the potion
                            active_bird.launch_potion(potion_launch_angle_rad)
                            # No need to play sound here, it was played on MOUSEBUTTONDOWN for aiming start

                        elif mouse_pressed_to_shoot:
                            pu = scale_pos(140, 420)
                            mouse_pressed_to_shoot = False
                            # Launch a bird
                            if level.number_of_birds > 0:
                                level.number_of_birds -= 1
                                t1 = time.time() * 1000
                                sx, sy = sling_anchor

                                impulse_factor = 60.0 # Increased significantly for a much stronger sling
                                
                                
                                impulse_x = -mouse_distance * impulse_factor * math.cos(launch_angle)
                                impulse_y = mouse_distance * impulse_factor * math.sin(launch_angle)
                                
                                # Update bird starting position to align with sling
                                bird_x = sx
                                bird_y = sy - 180 # Adjust vertical offset 
                                bird_x, bird_y = bird_x, bird_y
                                #print(f"levlebirds: {level.level_birds}")
                                bird = get_next_bird(mouse_distance, launch_angle, bird_x, bird_y, space, level, impulse_factor)
                                
                                birds.append(bird)
                                bird_path = []
                                level.level_birds.pop()
                                    
                                if level.number_of_birds == 0:
                                    t2 = time.time() # For timing or other logic if needed
                        
                        elif final_stop_button_rect.collidepoint(event.pos):
                            if sound_on:
                                click_sound.play()
                            game_state = 5
                            menu_open = True
                            menu_open_time = time.time()
                        else: # Click was not for Patapim aiming, sling, or pause. Check for other bird abilities.
                            if birds: # Check if there's an active bird
                                active_bird = birds[-1]
                                if not isinstance(active_bird, ch.Patapim): # Patapim's ability is now hold-and-release
                                    # Ensure this click wasn't meant for the pause button (even though it's in an else, this is a safeguard)
                                    if not final_stop_button_rect.collidepoint(event.pos): # Check if the click was on the pause button
                                        time_since_resume = time.time() - last_resume_time
                                        cooldown_passed = time_since_resume >= 0.2 

                                        can_use_ability = not active_bird.fahigkeit_verwendet and cooldown_passed
                                        
                                        if not isinstance(active_bird, ch.Glorbo) and not isinstance(active_bird, ch.Palocleves):
                                            can_use_ability = can_use_ability and not active_bird.bird_hit_ground
                                        
                                        was_fahigkeit_verwendet_before = active_bird.fahigkeit_verwendet 
                                        if can_use_ability:
                                            ability_result = active_bird.fahigkeit()

                                            if not was_fahigkeit_verwendet_before and active_bird.fahigkeit_verwendet:
                                                if isinstance(active_bird, ch.Palocleves): 
                                                    if sound_on and bird_ability_explosion_sounds_list: # Use new sound list
                                                        random.choice(bird_ability_explosion_sounds_list).play()
                                                    # Create visual explosion for Palocleves
                                                    palocleves_explosion_visual = ch.Explosion(
                                                        center_pos_world=active_bird.body.position,
                                                        frame_folder_path=PALOCLEVES_EXPLOSION_FRAME_FOLDER,
                                                        frame_duration_ms=PALOCLEVES_EXPLOSION_FRAME_DURATION_MS,
                                                        scale_factor_tuple_px=PALOCLEVES_EXPLOSION_SCALE_PX,
                                                        to_pygame_func=to_pygame
                                                    )
                                                    active_explosions.add(palocleves_explosion_visual)

                                                elif sound_on: 
                                                    if isinstance(active_bird, ch.Sahur):
                                                        sahur_bat_ability_sound.play()
                                                    elif isinstance(active_bird, ch.Bomb):
                                                        bomb_wind_ability_sound.play()
                                                    elif isinstance(active_bird, ch.Glorbo):
                                                        glorbo_balloon_ability_sound.play()
                                                    elif isinstance(active_bird, ch.Trala):
                                                        trala_turbo_ability_sound.play()

                                            if ability_result: 
                                                if "pigs" in ability_result and ability_result["pigs"] > 0:
                                                    score += ability_result["pigs"] * PIG_KO_SCORE
                                                if "polys" in ability_result and ability_result["polys"] > 0:
                                                    score += ability_result["polys"] * POLY_DESTROY_SCORE
                elif event.type == pg.MOUSEMOTION:
                    if patapim_is_aiming_potion and birds and isinstance(birds[-1], ch.Patapim):
                        x_mouse, y_mouse = event.pos # Update live mouse coordinates for trajectory drawing

                elif game_state == 5:
                    if event.type == pg.MOUSEBUTTONUP and event.button == 1:
                        x_mouse, y_mouse = event.pos

                        # Resume button (stop icon in pause menu)
                        # The final_stop_button_rect is defined for the gameplay screen's pause button.
                        # For the pause menu, the button is drawn at a different scaled size if menu_son/sof is used.
                        # Let's assume the pause menu's resume button is also at scale_pos(8,8) and uses the same scaled stop_button visual.
                        if final_stop_button_rect.collidepoint(x_mouse, y_mouse): # Using the same rect as gameplay pause
                            if not is_resuming: # Only trigger if not already resuming
                                is_resuming = True
                                resuming_initiated_time = time.time()
                                # The game state change will be handled by the logic at the top of game_state == 5

                        # Other pause menu buttons, only active if not currently trying to resume
                        elif not is_resuming:
                            # Restart button
                            if (scale_x * 80 + replay_button.get_width()*scale_x > x_mouse > scale_x * 80 and
                                scale_y *170 + replay_button.get_height()*scale_y > y_mouse >  scale_y *190):
                                if sound_on:
                                    click_sound.play()
                                restart()
                                level.load_level()
                                floor.build_lines(loch_extent_x=level.loch_extent_x)
                                game_state = 0 # Restart is immediate
                                bird_path = []
                                score = 0
                                menu_open = False # Ensure menu is marked as closed on restart
                            # Levels button
                            elif (scale_x * 105 + menu_button.get_width()*scale_x > x_mouse > scale_x * 105 and
                                scale_y *307 + menu_button.get_height()*scale_y > y_mouse > scale_y*307):
                                if sound_on:
                                    click_sound.play()
                                game_state = 6
                                levels_drawn = False
                            # Sound button
                            elif (scale_x * 60 + sound_button.get_width()*scale_x > x_mouse > scale_x * 55 and
                                scale_y * 565 + sound_button.get_height()*scale_y > y_mouse > scale_y * 565):
                                sound_on = not sound_on
                                if sound_on: # Play click even when turning on
                                    click_sound.play()

                elif game_state == 4:
                    if event.type == pg.MOUSEBUTTONUP and event.button == 1:
                        x_mouse, y_mouse = event.pos

                        if (680*scale_x + next_button.get_width()*scale_x > x_mouse > scale_x*680 and
                                scale_y*480 + next_button.get_height()*scale_y > y_mouse > scale_y*480):
                            if sound_on:
                                click_sound.play()
                            restart()
                            level.number += 1
                            game_state = 0
                            floor.build_lines(loch_extent_x=level.loch_extent_x) # Update floor for new level
                            level.load_level()
                            score = 0
                            bird_path = []
                            bonus_score_once = True

                        elif (570*scale_x + replay_button.get_width()*scale_x > x_mouse > scale_x*570 and
                            480*scale_y + replay_button.get_height()*scale_y > y_mouse > 480*scale_y):
                            if sound_on:
                                click_sound.play()
                            restart()
                            level.load_level()
                            floor.build_lines(loch_extent_x=level.loch_extent_x)
                            game_state = 0
                            bird_path = []
                            score = 0

                        elif (460*scale_x + menu_button.get_width()*scale_x > x_mouse > 460*scale_x and
                            480*scale_y + menu_button.get_height()*scale_y > y_mouse > 480*scale_y):
                            if sound_on:
                                click_sound.play()
                            game_state = 6
                            levels_drawn = False

                elif game_state == 3:
                    if event.type == pg.MOUSEBUTTONUP and event.button == 1:
                        x_mouse, y_mouse = event.pos

                        if (570*scale_x + replay_button.get_width()*scale_x > x_mouse > scale_x*570 and
                            480*scale_y + replay_button.get_height()*scale_y > y_mouse > 480*scale_y):
                            if sound_on:
                                click_sound.play()
                            restart()
                            level.load_level()
                            floor.build_lines(loch_extent_x=level.loch_extent_x)
                            game_state = 0
                            bird_path = []
                            score = 0

                        elif (460*scale_x + menu_button.get_width()*scale_x > x_mouse > 460*scale_x and
                            480*scale_y + menu_button.get_height()*scale_y > y_mouse > 480*scale_y):
                            if sound_on:
                                click_sound.play()
                            game_state = 6
                            levels_drawn = False


                elif game_state == 6:
                    
                        if event.type == pg.MOUSEBUTTONUP and event.button == 1:
                            x_mouse, y_mouse = event.pos
                            level_icon_rect = level_icon.get_rect()

                            # Calculate visible levels for the current page
                            start_level_index_on_page = current_level_page * LEVELS_PER_PAGE
                            
                            # Base positions and spacing for icons
                            base_x_icon, base_y_icon = 100, 50
                            base_spacing_x_icon, base_spacing_y_icon = 151, 160
                            levels_per_row_display = 7

                            for i_on_page in range(LEVELS_PER_PAGE):
                                level_idx_overall = start_level_index_on_page + i_on_page
                                if level_idx_overall >= MAX_LEVELS:
                                    break # Stop if we've run out of levels

                                level_number_to_check = level_idx_overall + 1

                                row = i_on_page // levels_per_row_display
                                col = i_on_page % levels_per_row_display
                                
                                icon_base_x = base_x_icon + (col * base_spacing_x_icon)
                                icon_base_y = base_y_icon + (row * base_spacing_y_icon)
                                
                                # Scale icon size and position
                                scaled_icon_width = int(100 * scale_x) # Assuming icon base size is 100x100
                                scaled_icon_height = int(100 * scale_y)
                                icon_screen_x, icon_screen_y = scale_pos(icon_base_x, icon_base_y)
                                
                                current_icon_rect = pg.Rect(icon_screen_x, icon_screen_y, scaled_icon_width, scaled_icon_height)
                                
                                if current_icon_rect.collidepoint(x_mouse, y_mouse):
                                    if sound_on:
                                        click_sound.play()
                                    with open("cleared_levels.txt","r+") as f:
                                        if str(level_number_to_check) in [line.rstrip("\n") for line in f.readlines()]:
                                            restart()
                                            level.number = level_number_to_check
                                            level.load_level() # Load the level properly
                                            floor.build_lines(loch_extent_x=level.loch_extent_x) # Update floor based on new level
                                            
                                            game_state = 0
                                            levels_drawn = False
                                            bird_path = []
                                            score = 0
                                            bonus_score_once = True
                                            break
                            b_size_scaled = scale_size(menu_button.get_width(),menu_button.get_height()) # Scaled menu button
                            
                            if (101*scale_x + b_size_scaled[0] > x_mouse > 101*scale_x and
                                    55*scale_y + b_size_scaled[1] > y_mouse > 55*scale_y):
                                # This was for going from levels menu to game_state 0, seems unused.
                                # if sound_on: click_sound.play()
                                game_state = 0
                                levels_drawn = False
                            
                            else: 
                                # Back arrow to main menu (game_state 7)
                                back_arrow_base_pos_x, back_arrow_base_pos_y = 30, 570
                                back_arrow_base_width, back_arrow_base_height = 100, 60 

                                scaled_back_arrow_pos_x, scaled_back_arrow_pos_y = scale_pos(back_arrow_base_pos_x, back_arrow_base_pos_y)
                                scaled_back_arrow_width = back_arrow_base_width * scale_x
                                scaled_back_arrow_height = back_arrow_base_height * scale_y

                                back_arrow_rect = pg.Rect(
                                    scaled_back_arrow_pos_x, scaled_back_arrow_pos_y,
                                    scaled_back_arrow_width, scaled_back_arrow_height
                                )

                                if back_arrow_rect.collidepoint(x_mouse, y_mouse):
                                    if sound_on:
                                        click_sound.play()
                                    game_state = 7
                                    active_explosions.empty() # Clear explosions when going to main menu
                                    levels_drawn = False
                                
                                # Previous Page Button
                                num_pages = (MAX_LEVELS + LEVELS_PER_PAGE - 1) // LEVELS_PER_PAGE
                                prev_page_button_base_pos = (30, 500) # Adjust as needed
                                prev_page_button_size = (100 * scale_x, 60 * scale_y) # Same as back arrow
                                prev_page_button_rect = pg.Rect(scale_pos(*prev_page_button_base_pos), prev_page_button_size)

                                if current_level_page > 0 and prev_page_button_rect.collidepoint(x_mouse, y_mouse):
                                    if sound_on:
                                        click_sound.play()
                                    current_level_page -=1
                                    levels_drawn = False
                                
                                # Next Page Button
                                next_page_button_base_pos = (1070, 500) # Adjust as needed
                                next_page_button_size = (100 * scale_x, 60 * scale_y) # Same as back arrow
                                next_page_button_rect = pg.Rect(scale_pos(*next_page_button_base_pos), next_page_button_size)

                                if current_level_page < num_pages - 1 and next_page_button_rect.collidepoint(x_mouse, y_mouse):
                                    if sound_on:
                                        click_sound.play()
                                    current_level_page +=1
                                    levels_drawn = False

                elif event.type == pg.VIDEORESIZE: # Handle resize in levels menu too
                    handle_resize(event)
                    levels_drawn = False # Force redraw of levels menu
                elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE: # Main menu on ESC
                    game_state = 7

                                

            if game_state == 0:
                #print(level.level_birds)
                #print(birds)
                try:
                    bird_img = pg.transform.scale(pg.image.load(load_resource(f"./resources/images/{level.level_birds[-1]}.png")).convert_alpha(),scale_size(30,30))
                except IndexError as e:
                    pass
                    
                menu_open = False
                screen.fill((130, 200, 100))
                bg_scaled = pg.transform.scale(bg, (screen_width, screen_height))
                screen.blit(bg_scaled, (0, 0))

                # Draw loch water background if a loch exists in the level
                if level.loch_extent_x:
                    water_polygon_world_coords = []
                    # Check if the level object has specific overrides for rectangular loch water fill
                    if hasattr(level, 'loch_water_surface_y_override') and \
                       hasattr(level, 'loch_rect_bottom_y_for_water_fill') and \
                       level.loch_water_surface_y_override is not None and \
                       level.loch_rect_bottom_y_for_water_fill is not None:
                        
                        lsx, lex = level.loch_extent_x
                        loch_top_y = level.loch_water_surface_y_override
                        loch_bottom_y = level.loch_rect_bottom_y_for_water_fill
                        
                        water_polygon_world_coords = [
                            Vec2d(lsx, loch_top_y),        # Top-Left
                            Vec2d(lex, loch_top_y),        # Top-Right
                            Vec2d(lex, loch_bottom_y),     # Bottom-Right
                            Vec2d(lsx, loch_bottom_y)      # Bottom-Left
                        ]
                    else:
                        # Fallback for non-rectangular lochs or those without overrides
                        loch_segments = [s for s in level.static_terrain_shapes if hasattr(s, 'terrain_type') and s.terrain_type == "loch" and isinstance(s, pm.Segment)]
                        if loch_segments:
                            unique_basin_points_world = set()
                            for seg in loch_segments:
                                unique_basin_points_world.add(seg.a)
                                unique_basin_points_world.add(seg.b)
                            
                            sorted_basin_points_world = sorted(list(unique_basin_points_world), key=lambda p: (p.x, p.y))

                            if len(sorted_basin_points_world) >= 2:
                                water_polygon_world_coords.append(Vec2d(level.loch_extent_x[0], WATER_SURFACE_Y_DEFAULT)) # Top-left
                                water_polygon_world_coords.append(Vec2d(level.loch_extent_x[1], WATER_SURFACE_Y_DEFAULT)) # Top-right
                                water_polygon_world_coords.extend(reversed(sorted_basin_points_world)) # Bottom contour R-L

                    if water_polygon_world_coords: # If we have points, draw the water
                        water_polygon_screen_coords = [to_pygame(v) for v in water_polygon_world_coords]
                        if len(water_polygon_screen_coords) >= 3:
                            # The rest of the texturing logic (calculating bounding box, tiling, masking) remains the same.
                                # Calculate bounding box of the water polygon
                                min_x_poly_s = min(p[0] for p in water_polygon_screen_coords)
                                max_x_poly_s = max(p[0] for p in water_polygon_screen_coords)
                                min_y_poly_s = min(p[1] for p in water_polygon_screen_coords)
                                max_y_poly_s = max(p[1] for p in water_polygon_screen_coords)

                                rect_x_s = min_x_poly_s
                                rect_y_s = min_y_poly_s
                                rect_width_s = max_x_poly_s - rect_x_s
                                rect_height_s = max_y_poly_s - rect_y_s

                                if rect_width_s > 0 and rect_height_s > 0:
                                    water_fill_surface = pg.Surface((int(rect_width_s), int(rect_height_s)), pg.SRCALPHA)
                                    tex_w, tex_h = water_texture.get_size()

                                    # Tile texture, offsetting for world alignment based on bounding box top-left
                                    tile_start_x_offset = -(int(rect_x_s) % tex_w)
                                    tile_start_y_offset = -(int(rect_y_s) % tex_h)
                                    for x_offset in range(tile_start_x_offset, int(rect_width_s), tex_w):
                                        for y_offset in range(tile_start_y_offset, int(rect_height_s), tex_h):
                                            water_fill_surface.blit(water_texture, (x_offset, y_offset))

                                    # Create mask from the water polygon
                                    mask_surf = pg.Surface((int(rect_width_s), int(rect_height_s)), pg.SRCALPHA)
                                    local_poly_points_s = [(p[0] - rect_x_s, p[1] - rect_y_s) for p in water_polygon_screen_coords]
                                    pg.draw.polygon(mask_surf, WHITE, local_poly_points_s)

                                    # Apply mask and blit
                                    water_fill_surface.blit(mask_surf, (0,0), special_flags=pg.BLEND_RGBA_MULT)
                                    screen.blit(water_fill_surface, (rect_x_s, rect_y_s))

                x_mouse, y_mouse = pg.mouse.get_pos()
                # mouse_pressed_to_shoot is now set on MOUSEBUTTONDOWN, not checked live here for sling_action
                if mouse_pressed_to_shoot and (110 * scale_x < x_mouse < 170 * scale_x and 250 * scale_y < y_mouse < 400 * scale_y):
                    mouse_pressed_to_shoot = True

                # screen.blit(slingr, scale_pos(130, 400)) # Example of old/debug code?
                
                # Draw birds waiting behind the sling
                if level.number_of_birds > 0: # If there are birds left to shoot
                    #print(level.number_of_birds,level.level_birds)
                    for i in range(level.number_of_birds-1):
                        #print(i)
                        
                        bird_type = level.level_birds[-i-2]
                        try:
                            bird_behind_img = pg.transform.scale(pg.image.load(load_resource(f"./resources/images/{bird_type}.png")).convert_alpha(),scale_size(30,30))
                            
                            x_position = 100 - i * 35
                            screen.blit(bird_behind_img, scale_pos(x_position, 445))
                            #print(scale_pos(0,435))
                        except FileNotFoundError:
                            print(f"Error: Bird image not found for {bird_type}")
                if mouse_pressed_to_shoot and level.number_of_birds > 0:
                    sling_action() 
                    
                # Draw bird in the sling if ready (not being dragged)
                elif level.number_of_birds > 0 and not patapim_is_aiming_potion: # Bird is waiting in sling, and Patapim isn't aiming
                    slingl_x, slingl_y = get_sling_positions()
                    slingr_x, slingr_y = get_sling_positions()
                    screen.blit(bird_img, scale_pos(130, 370))
                    
                    
                    
                    screen.blit(slingl, (slingl_x, slingl_y))
                    screen.blit(slingr, (slingr_x, slingr_y))
                elif not patapim_is_aiming_potion: # No birds left (or Patapim is aiming), draw empty sling if not aiming
                    default_x = 140 * scale_x
                    default_y = 420 * scale_y
                    slingl_x, slingl_y = get_sling_positions()
                    slingr_x, slingr_y = get_sling_positions()
                    pg.draw.line(screen, (0, 0, 0), (slingr_x + 4 * scale_x, slingr_y + 3 * scale_y), (default_x, default_y), 5)
                    pg.draw.line(screen, (0, 0, 0), (slingl_x + 2 * scale_x, slingl_y + 13 * scale_y), (default_x, default_y), 5)

                bird_to_remove = []
                pig_to_remove = []


                # Track bird path
                for bird in birds:                
                    p = to_pygame(bird.shape.body.position)
                    x, y = p
                    angle_degree = math.degrees(bird.shape.body.angle)
                    
                    # Get bird's base design size (e.g., 30x30, 50x50)
                    base_design_width = bird.scale[0]
                    base_design_height = bird.scale[1]

                    # --- Glorbo's visual growth effect ---
                    current_bird_visual_scale_multiplier = 1.0 # Default for other birds or inactive Glorbo
                    if isinstance(bird, ch.Glorbo) and bird.is_ability_visually_active:
                        if bird.is_growing: # Visual grows with physical
                            time_since_activation = time.time() - bird.ability_activation_time
                            growth_progress = min(time_since_activation / bird.growth_duration, 1.0)
                            
                            bird.current_visual_scale_multiplier = bird.initial_visual_scale + \
                                (bird.ability_visual_scale_multiplier - bird.initial_visual_scale) * growth_progress
                            current_bird_visual_scale_multiplier = bird.current_visual_scale_multiplier
                        elif bird.fahigkeit_verwendet: # If grown and ability used, keep large size
                            current_bird_visual_scale_multiplier = bird.ability_visual_scale_multiplier
                        # else: if ability not active, it remains 1.0 (default)
                                    
                    # Final pixel size for the bird, including screen scaling
                    # Formula: (DesignSize * VisualMultiplier) * ScreenScale
                    final_pixel_width = int(base_design_width * current_bird_visual_scale_multiplier * scale_x)
                    final_pixel_height = int(base_design_height * current_bird_visual_scale_multiplier * scale_y)

                    # Load fresh image for best scaling quality
                    original_bird_surface = pg.image.load(load_resource(bird.img)).convert_alpha()
                    
                    # Scale it
                    scaled_bird_surface = pg.transform.scale(original_bird_surface, (final_pixel_width, final_pixel_height))
                    
                    # And rotate
                    rotated_image = pg.transform.rotate(scaled_bird_surface, angle_degree)

                    # --- Glorbo's physics growth (hitbox, mass) ---
                    if isinstance(bird, ch.Glorbo) and bird.is_growing:
                        time_since_activation = time.time() - bird.ability_activation_time # Reuse time_since_activation
                        growth_progress = min(time_since_activation / bird.growth_duration, 1.0)

                        # Target physical radius based on visual scale
                        # Visual "radius" is half its design width
                        initial_visual_design_radius = bird.scale[0] / 2.0
                        desired_target_physical_radius = initial_visual_design_radius * bird.ability_visual_scale_multiplier
                        
                        # Lerp physical radius
                        # initial_physical_radius was Pymunk radius at activation
                        current_physical_radius = bird.initial_physical_radius + \
                                                (desired_target_physical_radius - bird.initial_physical_radius) * growth_progress
                        
                        # Mass scales with area (multiplier^2)
                        # Prevent mass increase by keeping target_mass as initial_mass
                        target_mass = bird.initial_mass
                        current_mass = bird.initial_mass + (target_mass - bird.initial_mass) * growth_progress
                        bird.shape.unsafe_set_radius(current_physical_radius)
                        bird.body.mass = current_mass
                        bird.body.moment = pm.moment_for_circle(current_mass, 0, current_physical_radius, (0,0)) # Update moment of inertia
                        space.reindex_shape(bird.shape)

                        if growth_progress >= 1.0:
                            bird.is_growing = False
                            # Ensure final values are set precisely
                            bird.shape.unsafe_set_radius(desired_target_physical_radius)
                            bird.body.mass = target_mass # target_mass is already the final desired mass
                            bird.body.moment = pm.moment_for_circle(target_mass, 0, desired_target_physical_radius, (0,0)) # Final moment
                            space.reindex_shape(bird.shape) # Reindex shape one last time
                    
                    # Offset for blitting rotated image
                    offset = Vec2d(*rotated_image.get_size()) / 2
                    blit_x = p[0] - offset[0] # Blit using scaled center x
                    blit_y = p[1] - offset[1] # Blit using scaled center y
                    
                    if not bird.bird_hit_ground: # Add to trail if bird hasn't hit ground
                        bird_path.append(p) # p is already scaled center
            
                    
                    screen.blit(rotated_image, (blit_x, blit_y))
                    
                    if (bird.body.position.y < 0 or bird.body.position.x < -50 or
                            bird.body.position.x > screen_width + 50):
                        if bird not in bird_to_remove:
                            bird_to_remove.append(bird)
                            if sound_on and bird_exit_sound: # Play exit sound
                                bird_exit_sound.play()
                    
                    # Check for Palocleves' self-destruction after explosion
                    if hasattr(bird, 'exploded') and bird.exploded and bird not in bird_to_remove:
                        bird_to_remove.append(bird)
                        # Palocleves already makes an explosion sound, so no separate exit sound here.
                    

                    current_time = time.time() * 1000
                    if current_time - bird.launch_time > 7000: # Birds live for 7 secs
                        if bird not in bird_to_remove: # Check if not already added for other reasons
                            bird_to_remove.append(bird)
                            if sound_on and bird_exit_sound: # Play exit sound for timeout
                                bird_exit_sound.play()
                            bird_path = []  # Clear trail if this bird is removed due to timeout
                        elif bird in bird_to_remove and not bird_path: # If already marked for removal but path not cleared (e.g. out of bounds)
                            bird_path = [] # Ensure path is cleared

                #for bird_to_remove in bird_to_remove:
                #    if bird_to_remove in birds: # Check if the bird is still in the list
                #        space.remove(bird_to_remove.shape, bird_to_remove.body)
                #        birds.remove(bird_to_remove)

                # Draw bird path
                for i, point in enumerate(bird_path):
                    if i % 5 == 0:  # Draw every 5th stored point
                        # 'point' is already a scaled tuple (x, y) from to_pygame
                        pg.draw.circle(screen, WHITE, point, 3) 

                # --- Draw Patapim's Aiming Trajectory ---
                if patapim_is_aiming_potion and birds and isinstance(birds[-1], ch.Patapim):
                    active_bird = birds[-1]
                    patapim_aim_trajectory_points.clear()

                    # Potion's effective start position for preview (Pymunk world coordinates)
                    preview_offset_distance = active_bird.radius + 10 # Approx potion radius
                    preview_offset_x = math.cos(active_bird.body.angle) * preview_offset_distance
                    preview_offset_y = math.sin(active_bird.body.angle) * preview_offset_distance
                    sim_pos = active_bird.body.position + Vec2d(preview_offset_x, preview_offset_y)

                    # Target mouse position in Pymunk world coordinates (x_mouse, y_mouse are live screen coords)
                    target_world_mouse_pos = screen_to_world(x_mouse, y_mouse, screen_height, scale_x, scale_y)

                    delta_x_world = target_world_mouse_pos.x - sim_pos.x 
                    delta_y_world = target_world_mouse_pos.y - sim_pos.y
                    
                    if delta_x_world == 0 and delta_y_world == 0: 
                        direction_norm = Vec2d(0,1) 
                    else:
                        direction_norm = Vec2d(delta_x_world, delta_y_world).normalized()

                    potion_mass = 2 
                    POTION_THROW_IMPULSE_MAGNITUDE = 1000 # Must match Patapim.launch_potion (Reduced)
                    initial_speed = POTION_THROW_IMPULSE_MAGNITUDE / potion_mass
                    sim_vel = direction_norm * initial_speed
                    
                    # Optional: Add a portion of Patapim's current velocity to the preview
                    # sim_vel += active_bird.body.velocity * 0.1 

                    dt_preview = 0.03 
                    num_steps_preview = 40 

                    for _ in range(num_steps_preview):
                        sim_vel = Vec2d(sim_vel.x, sim_vel.y + space.gravity.y * dt_preview) 
                        sim_pos += sim_vel * dt_preview
                        patapim_aim_trajectory_points.append(to_pygame(sim_pos))
                    for point in patapim_aim_trajectory_points:
                        pg.draw.circle(screen, WHITE, point, 3) # Draw the trail dot

                # Clean up birds marked for removal
                # Iterate a copy if modifying the list, or clear original at end.
                processed_birds_this_frame = list(bird_to_remove) # Copy to iterate safely
                bird_to_remove.clear() # Clear original for next frame

                for bird_instance_to_remove in processed_birds_this_frame:
                    # Sahur's bat cleanup
                    if isinstance(bird_instance_to_remove, ch.Sahur) and \
                    hasattr(bird_instance_to_remove, 'ability_polygon') and bird_instance_to_remove.ability_polygon:
                        poly_to_remove = bird_instance_to_remove.ability_polygon
                        if poly_to_remove in columns:
                            # Only remove from Pymunk if it's there
                            if poly_to_remove.shape and poly_to_remove.shape in space.shapes:
                                space.remove(poly_to_remove.shape, poly_to_remove.body)
                                poly_to_remove.in_space = False # Keep our 'in_space' flag consistent
                            columns.remove(poly_to_remove)
                        bird_instance_to_remove.ability_polygon = None

                    # Glorbo: no ability polygon to clean

                    # Remove the bird object
                    if bird_instance_to_remove in birds: # Double check it's still in birds list
                        if bird_instance_to_remove.body and bird_instance_to_remove.shape:
                            space.remove(bird_instance_to_remove.shape, bird_instance_to_remove.body)
                        birds.remove(bird_instance_to_remove)
                
                if processed_birds_this_frame: # If birds were removed, clear the trail
                    bird_path = []

                for pig in pigs:
                    if pig.shape.body.position.y < 0:
                        pig_to_remove.append(pig)
                        # print(pigs) # debug
                
                for pig in pig_to_remove:
                    space.remove(pig.body)
                    pigs.remove(pig) # also remove from our list

                for line in floor.static_lines:
                    pv1 = line.a 
                    pv2 = line.b
                    p1 = to_pygame(pv1)
                    p2 = to_pygame(pv2)
                    # Let's make the main ground line visible brown
                    pg.draw.line(screen, (139, 69, 19), p1, p2, max(1, int(5 * scale_y))) # Brown, 5px base thickness

                # Draw additional static terrain elements (hills, lochs)
                # terrain_color = (34, 139, 34) # Forest Green - No longer needed if texturing
                for terrain_shape in level.static_terrain_shapes:
                    if isinstance(terrain_shape, pm.Segment):
                        # --- Existing Segment Texturing Logic ---
                        current_segment_texture = terrain_texture # Default to hill/ground texture
                        if hasattr(terrain_shape, 'terrain_type'):
                            if terrain_shape.terrain_type == "loch":
                                current_segment_texture = water_texture
                            elif terrain_shape.terrain_type == "hill":
                                current_segment_texture = terrain_texture
                            # Add more types here if needed


                        # For segments attached to space.static_body, their coordinates are already absolute.
                        pv1 = terrain_shape.a 
                        pv2 = terrain_shape.b
                        p1_screen = to_pygame(pv1)
                        p2_screen = to_pygame(pv2)
                        
                        # Scaled radius (half-thickness of the segment in pixels)
                        r_pixels = terrain_shape.radius * ((scale_x + scale_y) / 2.0)
                        # Ensure minimum 1 pixel for very thin segments if scaled down too much
                        r_pixels = max(0.5, r_pixels) 

                        # Calculate screen-space direction and normal for the segment
                        dx_s = p2_screen[0] - p1_screen[0]
                        dy_s = p2_screen[1] - p1_screen[1]
                        seg_len_s = math.hypot(dx_s, dy_s)

                        if seg_len_s == 0: # Skip zero-length segments
                            continue

                        # Normalized perpendicular vector on screen
                        nx_s = -dy_s / seg_len_s
                        ny_s = dx_s / seg_len_s

                        # Four corners of the thick segment polygon
                        poly_vertices_screen = [
                            (p1_screen[0] + nx_s * r_pixels, p1_screen[1] + ny_s * r_pixels),
                            (p2_screen[0] + nx_s * r_pixels, p2_screen[1] + ny_s * r_pixels),
                            (p2_screen[0] - nx_s * r_pixels, p2_screen[1] - ny_s * r_pixels),
                            (p1_screen[0] - nx_s * r_pixels, p1_screen[1] - ny_s * r_pixels)
                        ]

                        # Bounding box of the polygon
                        min_x_poly = min(p[0] for p in poly_vertices_screen)
                        max_x_poly = max(p[0] for p in poly_vertices_screen)
                        min_y_poly = min(p[1] for p in poly_vertices_screen)
                        max_y_poly = max(p[1] for p in poly_vertices_screen)

                        rect_x = min_x_poly
                        rect_y = min_y_poly
                        rect_width = max_x_poly - min_x_poly
                        rect_height = max_y_poly - min_y_poly

                        if rect_width > 0 and rect_height > 0:
                            segment_texture_surf = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                            tex_w, tex_h = current_segment_texture.get_size()

                            # Tile the texture onto segment_texture_surf, offsetting for world alignment
                            tile_start_x = -(int(rect_x) % tex_w)
                            tile_start_y = -(int(rect_y) % tex_h)
                            for x_offset in range(tile_start_x, int(rect_width), tex_w):
                                for y_offset in range(tile_start_y, int(rect_height), tex_h):
                                    segment_texture_surf.blit(current_segment_texture, (x_offset, y_offset))

                            # Create mask
                            mask_surf = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                            local_poly_points = [(p[0] - rect_x, p[1] - rect_y) for p in poly_vertices_screen]
                            pg.draw.polygon(mask_surf, WHITE, local_poly_points)

                            segment_texture_surf.blit(mask_surf, (0, 0), special_flags=pg.BLEND_RGBA_MULT)
                            screen.blit(segment_texture_surf, (rect_x, rect_y))
                        else: # Fallback if rect is invalid (e.g., zero width/height)
                            pg.draw.line(screen, (34,139,34), p1_screen, p2_screen, max(1, int(r_pixels * 2)))
                    
                    elif isinstance(terrain_shape, pm.Poly) and terrain_shape.body == space.static_body:
                        # --- New Static Polygon (Hill Triangle) Texturing Logic ---
                        current_poly_texture = terrain_texture # Default
                        if hasattr(terrain_shape, 'terrain_type'):
                            if terrain_shape.terrain_type == "hill":
                                current_poly_texture = terrain_texture
                            # Add other types if static polys are used for lochs etc. later
                        
                        # Vertices are already in world coordinates for static polys
                        world_vertices = terrain_shape.get_vertices()
                        if not world_vertices:
                            continue

                        screen_poly_vertices = [to_pygame(v) for v in world_vertices]

                        if len(screen_poly_vertices) < 3: # Need at least a triangle
                            continue

                        # Bounding box of the screen polygon
                        min_x_poly = min(p[0] for p in screen_poly_vertices)
                        max_x_poly = max(p[0] for p in screen_poly_vertices)
                        min_y_poly = min(p[1] for p in screen_poly_vertices)
                        max_y_poly = max(p[1] for p in screen_poly_vertices)

                        rect_x = min_x_poly
                        rect_y = min_y_poly
                        rect_width = max_x_poly - min_x_poly
                        rect_height = max_y_poly - min_y_poly

                        if rect_width > 0 and rect_height > 0:
                            poly_texture_surf = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                            tex_w, tex_h = current_poly_texture.get_size()

                            # Tile the texture, offsetting for world alignment
                            tile_start_x = -(int(rect_x) % tex_w)
                            tile_start_y = -(int(rect_y) % tex_h)
                            for x_offset in range(tile_start_x, int(rect_width), tex_w):
                                for y_offset in range(tile_start_y, int(rect_height), tex_h):
                                    poly_texture_surf.blit(current_poly_texture, (x_offset, y_offset))
                            
                            mask_surf = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                            local_poly_points = [(p[0] - rect_x, p[1] - rect_y) for p in screen_poly_vertices]
                            pg.draw.polygon(mask_surf, WHITE, local_poly_points) # Draw the filled triangle as mask
                            poly_texture_surf.blit(mask_surf, (0,0), special_flags=pg.BLEND_RGBA_MULT)
                            screen.blit(poly_texture_surf, (rect_x, rect_y))
                for pig in pigs:
                    pig_to_remove = []
                    pigg=pig
                    pig = pig.shape
                    p = to_pygame(pig.body.position)
                    x, y = p
                    angle_degree = math.degrees(pig.body.angle)
                    pig_initial_hp = 75 # As defined in Pig class
                    pig_damage_display_threshold = pig_initial_hp / 2 # Show damaged if life is half or less
                    
                    normal_img_surface = None
                    damaged_img_surface = None
                    
                    if pigg.type == "n11":
                        normal_img_surface = n11
                        damaged_img_surface = n12
                    elif pigg.type == "n21":
                        normal_img_surface = n21
                        damaged_img_surface = n22
                    elif pigg.type == "n31":
                        normal_img_surface = n31
                        damaged_img_surface = n32
                    elif pigg.type == "n41":
                        normal_img_surface = n41
                        damaged_img_surface = n42
                    elif pigg.type == "n51": # Corrected 'if' to 'elif'
                        normal_img_surface = n51
                        damaged_img_surface = n52
                    
                    pig_img_to_use = None
                    if normal_img_surface and damaged_img_surface:
                        if pigg.life > pig_damage_display_threshold:
                            pig_img_to_use = normal_img_surface
                        else: # Life is at or below threshold (and > 0, as it's still being drawn)
                            pig_img_to_use = damaged_img_surface
                    elif normal_img_surface: # Fallback if damaged surface is somehow not defined
                        pig_img_to_use = normal_img_surface

                    if pig_img_to_use:
                        pig_img = pg.transform.scale(pig_img_to_use, (pigg.radius*2, pigg.radius*2))
                    else:
                        # Fallback: draw a blue circle if no image determined (should not happen)
                        pg.draw.circle(screen, BLUE, p, int(pigg.radius * scale_x), 0) # scale_x for rough pixel radius
                        continue # Skip rotation and blit if no image

                    pig_img = pg.transform.rotate(pig_img, angle_degree)
                    width, height = pig_img.get_size()
                    rotated_image = pg.transform.rotate(pig_img, angle_degree)
                    offset = Vec2d(*rotated_image.get_size()) / 2
                    x -= offset[0]
                    y -= offset[1]
                    img_x, img_y = p[0]-width/2, p[1]-height/2
                    screen.blit(rotated_image, (x, y))
                    #pg.draw.circle(screen, BLUE, p, int(pig.radius), 2)
                    if (pig.body.position.y < 0 or pig.body.position.x < -50 or
                            pig.body.position.x > screen_width + 50):
                        #print(f"Pig removed: {pig.body.position}")
                        pig_to_remove.append(pig)
                    
                # Update bat position before drawing if Sahur's ability is active
                active_special_bird_instance = None # Will hold Sahur/Glorbo if ability active
                current_sahur_ability_polygon = None

                if birds: # Any active birds?
                    last_bird = birds[-1] # Current bird in flight
                    if last_bird.fahigkeit_verwendet: # Is its ability active?
                        if isinstance(last_bird, ch.Sahur):
                            active_special_bird_instance = last_bird
                            # Sahur's bat is stored in ability_polygon
                            if hasattr(last_bird, 'ability_polygon') and last_bird.ability_polygon:
                                current_sahur_ability_polygon = last_bird.ability_polygon
                        elif isinstance(last_bird, ch.Glorbo):
                            # Glorbo's ability is growth/stop
                            active_special_bird_instance = last_bird

                for column in columns:
                    # Sahur's bat logic
                    if column.element_type == "bats" and \
                    active_special_bird_instance and \
                    isinstance(active_special_bird_instance, ch.Sahur):
                            # Animation duration for bat swing & lifetime
                            animation_duration = 0.25 # Swing/lifetime is 0.25s

                            # Bat lifetime check for Sahur
                            if hasattr(active_special_bird_instance, 'ability_polygon_creation_time') and \
                            active_special_bird_instance.ability_polygon == column: # Is this Sahur's current bat?
                                bat_age = time.time() - active_special_bird_instance.ability_polygon_creation_time
                                if bat_age > animation_duration: 
                                    if column.body and column.shape: # Check body/shape exist before Pymunk removal
                                        if column.shape in space.shapes: # Is it still in Pymunk space?
                                            space.remove(column.shape, column.body)
                                    column.in_space = False # Mark Polygon as removed for our game logic
                                    if column in columns: # Still in 'columns' list?
                                        columns.remove(column)
                                    active_special_bird_instance.ability_polygon = None
                                    current_sahur_ability_polygon = None # Bat gone, nullify ref for this frame
                                    continue # Bat expired, skip rest of its logic

                            # If bat still alive, update its position
                            if active_special_bird_instance.ability_polygon == column: # Double check it wasn't just timed out
                                new_x = active_special_bird_instance.body.position.x + 50
                                new_y = active_special_bird_instance.body.position.y
                                column.body.position = Vec2d(new_x, new_y)

                                # Sahur's bat swing animation
                                bat_creation_time = active_special_bird_instance.ability_polygon_creation_time
                                current_time_for_swing = time.time() # Consistent time for age calc
                                bat_age_for_swing = current_time_for_swing - bat_creation_time
                                
                                # animation_duration defined earlier
                                start_angle_deg = 160.0 # Bat starts at 160 deg
                                end_angle_deg = 20.0   # Swings to 20 deg

                                if bat_age_for_swing <= animation_duration:
                                    progress = min(bat_age_for_swing / animation_duration, 1.0) # Ensure progress doesn't exceed 1.0
                                    current_angle_deg = start_angle_deg + (end_angle_deg - start_angle_deg) * progress
                                    column.body.angle = math.radians(current_angle_deg)
                                # else: The bat will be at end_angle_deg when it's about to be removed by the timer.

                                if column.shape: # Reindex if shape exists
                                    space.reindex_shape(column.shape)

                    if column.in_space: # Only draw if not removed by timer/collision
                        column.draw_poly(screen, column.shape)
                # Draw other polygons        
                
                # --- Manage Potion Pig Growth Effects ---
                current_time_for_effect_check = time.time()

                for pig_instance, data in list(growing_pigs_effects.items()):
                    if not pig_instance.body or not pig_instance.body.space: # Pig removed from space
                        if pig_instance in growing_pigs_effects: del growing_pigs_effects[pig_instance]
                        continue

                    time_elapsed = current_time_for_effect_check - data["start_time"]
                    growth_progress = min(time_elapsed / POTION_PIG_GROWTH_DURATION, 1.0)

                    # Interpolate visual radius (used for drawing)
                    target_visual_radius = data["original_visual_radius"] * POTION_PIG_GROWTH_SCALE_MULTIPLIER
                    current_visual_radius = data["original_visual_radius"] + (target_visual_radius - data["original_visual_radius"]) * growth_progress
                    pig_instance.radius = current_visual_radius

                    # Interpolate physics radius
                    target_physics_radius = data["original_physics_radius"] * POTION_PIG_GROWTH_SCALE_MULTIPLIER
                    current_physics_radius = data["original_physics_radius"] + (target_physics_radius - data["original_physics_radius"]) * growth_progress
                    pig_instance.shape.unsafe_set_radius(current_physics_radius)

                    # Interpolate mass (scales with area: multiplier^2)
                    target_mass = data["original_mass"] * (POTION_PIG_GROWTH_SCALE_MULTIPLIER**2)
                    current_mass = data["original_mass"] + (target_mass - data["original_mass"]) * growth_progress
                    pig_instance.body.mass = current_mass
                    pig_instance.body.moment = pm.moment_for_circle(current_mass, 0, current_physics_radius, (0,0))
                    
                    space.reindex_shape(pig_instance.shape) # Important after changing radius

                    if growth_progress >= 1.0:
                        print(f"DEBUG: Pig at {pig_instance.body.position} finished growing. New radius: {pig_instance.radius:.2f}")
                        pig_instance.is_potion_grown = True # Mark as fully grown by this effect
                        if pig_instance in growing_pigs_effects: del growing_pigs_effects[pig_instance]
                
            # --- Patapim Slowdown Check ---
                if patapim_slowdown_active:
                    if time.time() - patapim_slowdown_start_time > patapim_slowdown_duration:
                        patapim_slowdown_active = False
                        current_slowdown_factor = 1.0 # Reset to normal speed
                
                for beam in beams:
                    beam.draw_poly(screen,beam.shape)
                for circle in circles:
                    # Example: If you wanted to visually indicate slowdown, you could do it here
                    # if patapim_slowdown_active:
                    #     pg.draw.rect(screen, (0,0,255,50), screen.get_rect()) # Blueish overlay
                    circle.draw_poly(screen,circle.shape)
                    
                for triangle in triangles:
                    triangle.draw_poly(screen,triangle.shape)

                dt = 1.0 / 50.0 / 2.0 # physics simulation step
                for x in range(2):
                    effective_dt = dt * current_slowdown_factor # Apply slowdown
                    space.step(effective_dt)

                # Apply Buoyancy and Water Damping
                if level.loch_extent_x: # Check if the current level has a loch
                    gravity_magnitude = abs(space.gravity.y)
                    # Effective upward acceleration provided by buoyancy (counteracts gravity)
                    buoyant_acceleration_effect = gravity_magnitude * BUOYANCY_FACTOR

                    # Consolidate all dynamic objects that could be affected by water
                    all_dynamic_objects_in_level = []
                    # Ensure we only add objects that have a 'body' attribute
                    object_lists_to_check = [
                        [b for b in birds if hasattr(b, 'body')],
                        [p for p in pigs if hasattr(p, 'body')],
                        [c for c in columns if hasattr(c, 'body')],
                        [b_beam for b_beam in beams if hasattr(b_beam, 'body')],
                        [c_circle for c_circle in circles if hasattr(c_circle, 'body')],
                        [t for t in triangles if hasattr(t, 'body')]
                    ]
                    for obj_list in object_lists_to_check:
                        for obj_instance in obj_list:
                            # Ensure the object has a body and it's dynamic
                            if obj_instance.body and obj_instance.body.body_type == pm.Body.DYNAMIC:
                                all_dynamic_objects_in_level.append(obj_instance)
                    
                    for obj in all_dynamic_objects_in_level:
                        pos = obj.body.position
                        was_in_water = getattr(obj, 'in_water_flag', False)
                        is_currently_submerged = (level.loch_extent_x[0] < pos.x < level.loch_extent_x[1]) and \
                                                (pos.y < WATER_SURFACE_Y_DEFAULT)
                        
                        # Initialize has_splashed_this_submersion if not present
                        if not hasattr(obj, 'has_splashed_this_submersion'):
                            obj.has_splashed_this_submersion = False

                        if is_currently_submerged:
                            if not was_in_water: # Object just entered the water
                                obj.in_water_flag = True
                                # Only splash if it hasn't splashed during this current submersion
                                if not obj.has_splashed_this_submersion:
                                    # This flag ensures one splash per entry into water,
                                    # until the object fully exits and re-enters.
                                    obj.has_splashed_this_submersion = True 

                                    initial_momentum = obj.body.mass * obj.body.velocity.length
                                    
                                    obj.current_linear_damping_water = get_momentum_based_damping_factor(
                                        initial_momentum, MOMENTUM_LOW_THRESHOLD, MOMENTUM_HIGH_THRESHOLD,
                                        DAMPING_LINEAR_LOW_MOMENTUM, DAMPING_LINEAR_HIGH_MOMENTUM)
                                    
                                    obj.current_angular_damping_water = get_momentum_based_damping_factor(
                                        initial_momentum, MOMENTUM_LOW_THRESHOLD, MOMENTUM_HIGH_THRESHOLD,                                DAMPING_ANGULAR_LOW_MOMENTUM, DAMPING_ANGULAR_HIGH_MOMENTUM)
                                    
                                    # Cooldown logic for splash sound for this specific object.
                                    # Prevents sound spam if an object bobs rapidly at the surface.
                                    play_this_splash_sound = True
                                    current_event_time = time.time()
                                    if hasattr(obj, 'last_splash_sound_time'):
                                        if current_event_time - obj.last_splash_sound_time < SPLASH_SOUND_COOLDOWN:
                                            play_this_splash_sound = False
                                    
                                    if play_this_splash_sound:
                                        if sound_on and splash_sound:
                                            splash_sound.play()
                                        obj.last_splash_sound_time = current_event_time 
                                    
                                    # Create visual splash animation
                                    splash_center_world = Vec2d(pos.x, WATER_SURFACE_Y_DEFAULT) 
                                    splash_visual = ch.Explosion(
                                        center_pos_world=splash_center_world,
                                        frame_folder_path=SPLASH_FRAME_FOLDER,
                                        frame_duration_ms=SPLASH_FRAME_DURATION_MS,
                                        scale_factor_tuple_px=SPLASH_SCALE_PX,
                                        to_pygame_func=to_pygame
                                    )
                                    active_explosions.add(splash_visual)

                            # Apply buoyancy and damping if the object is submerged and has its water damping factors set
                            if hasattr(obj, 'current_linear_damping_water') and hasattr(obj, 'current_angular_damping_water'):
                                # Apply buoyancy force (upwards)
                                force_y = obj.body.mass * buoyant_acceleration_effect
                                buoyancy_force_vec = Vec2d(0, force_y)
                                obj.body.apply_force_at_local_point(buoyancy_force_vec, (0,0))
                                # Apply damping due to water
                                obj.body.velocity = obj.body.velocity * obj.current_linear_damping_water
                                obj.body.angular_velocity = obj.body.angular_velocity * obj.current_angular_damping_water
                            

                        else: # Not currently submerged
                            if was_in_water: # Object just exited the water
                                obj.in_water_flag = False
                                # Reset this flag when the object EXITS the water,
                                # so it can splash again on the NEXT entry.
                                obj.has_splashed_this_submersion = False 
                                # Clean up custom damping attributes so they are recalculated on next entry
                                if hasattr(obj, 'current_linear_damping_water'):
                                    del obj.current_linear_damping_water
                                if hasattr(obj, 'current_angular_damping_water'):
                                    del obj.current_angular_damping_water

                slingl_x, slingl_y = get_sling_positions()
                screen.blit(slingl, (slingl_x, slingl_y))
                screen.blit(slingr, (slingr_x, slingr_y))

                score_font = bold_font.render("SCORE", 1, WHITE)
                number_font = bold_font.render(str(score), 1, WHITE)

                screen.blit(score_font, scale_pos(1060, 90))
                if score == 0:
                    screen.blit(number_font, scale_pos(1150, 130))
                else:
                    screen.blit(number_font, scale_pos(1060, 130))

                # --- Draw stop_button with hover/press effects ---
                # final_stop_button_rect is already calculated based on original scaled size and position
                # We need to determine the image and potentially new position/size for blitting
                
                image_for_stop_button_blit = None
                blit_pos_stop_button = final_stop_button_rect.topleft # Default to original position
                
                # Base unscaled size for calculations
                stop_button_base_w, stop_button_base_h = 65, 65

                if stop_button_is_pressed:
                    scaled_w = int(stop_button_base_w * stop_button_pressed_scale_factor * scale_x)
                    scaled_h = int(stop_button_base_h * stop_button_pressed_scale_factor * scale_y)
                    
                    # Adjust blit position to keep the smaller button centered
                    offset_x_scaled = (final_stop_button_rect.width - scaled_w) / 2
                    offset_y_scaled = (final_stop_button_rect.height - scaled_h) / 2
                    blit_pos_stop_button = (final_stop_button_rect.left + offset_x_scaled, 
                                            final_stop_button_rect.top + offset_y_scaled)
                    
                    image_source = stop_button_darkened if stop_button_is_hovered else stop_button_original
                    image_for_stop_button_blit = pg.transform.scale(image_source, (scaled_w, scaled_h))
                elif stop_button_is_hovered:
                    image_for_stop_button_blit = pg.transform.scale(stop_button_darkened, final_stop_button_rect.size)
                else:
                    image_for_stop_button_blit = pg.transform.scale(stop_button_original, final_stop_button_rect.size)
                screen.blit(image_for_stop_button_blit, blit_pos_stop_button)

                if not pigs and not mouse_pressed_to_shoot and not restart_counter and not birds:
                    print("Level cleared! Setting game_state to 4")
                    game_state = 4
                    restart_counter = True

                if level.number_of_birds == 0 and pigs and not birds:
                    game_state = 3

            elif game_state == 5:
                # Check if we are in the process of resuming and if the delay has passed
                if is_resuming and (time.time() - resuming_initiated_time >= RESUME_DELAY):
                    game_state = 0
                    if sound_on: click_sound.play() # Play sound when resume action is confirmed
                    last_resume_time = time.time()  # Record actual resume time
                    game_just_resumed = True        # Prevent immediate action on resume
                    is_resuming = False             # Reset the flag
                    menu_open = False               # Ensure menu is marked as closed
                    # The game will now proceed to game_state 0 in the next loop iteration

                # Draw the pause menu
                menu_open = True
                if sound_on:
                    screen.blit(menu_son, scale_pos(0, 0))
                else:
                    screen.blit(menu_sof, scale_pos(0, 0))
                
                # --- Draw stop_button (acting as resume) in pause menu with hover/press effects ---
                # final_stop_button_rect is calculated at the start of the loop, still valid for collision.
                image_for_resume_button_blit = None
                blit_pos_resume_button = final_stop_button_rect.topleft
                
                stop_button_base_w_pause, stop_button_base_h_pause = 65, 65 # Same base size

                if stop_button_is_pressed: # Using the same stop_button_is_pressed state
                    scaled_w_pause = int(stop_button_base_w_pause * stop_button_pressed_scale_factor * scale_x)
                    scaled_h_pause = int(stop_button_base_h_pause * stop_button_pressed_scale_factor * scale_y)
                    
                    offset_x_pause_scaled = (final_stop_button_rect.width - scaled_w_pause) / 2
                    offset_y_pause_scaled = (final_stop_button_rect.height - scaled_h_pause) / 2
                    blit_pos_resume_button = (final_stop_button_rect.left + offset_x_pause_scaled, 
                                            final_stop_button_rect.top + offset_y_pause_scaled)
                    
                    image_source_pause = stop_button_darkened if stop_button_is_hovered else stop_button_original
                    image_for_resume_button_blit = pg.transform.scale(image_source_pause, (scaled_w_pause, scaled_h_pause))
                elif stop_button_is_hovered:
                    image_for_resume_button_blit = pg.transform.scale(stop_button_darkened, final_stop_button_rect.size)
                else:
                    image_for_resume_button_blit = pg.transform.scale(stop_button_original, final_stop_button_rect.size)
                screen.blit(image_for_resume_button_blit, blit_pos_resume_button)

                # Display current level number
                level_num_text_str = f"Level: {level.number}"
                level_num_surface = bold_font2.render(level_num_text_str, 1, WHITE) # Changed to bold_font2 for larger text
                # Position it on the pause menu (which is on the left, 250 base width)
                text_rect = level_num_surface.get_rect(centerx=(125 * scale_x), top=(20 * scale_y))
                screen.blit(level_num_surface, text_rect)

            elif game_state == 4:
                with open("cleared_levels.txt","r+") as f:
                    if str(level.number+1) not in [line.rstrip("\n") for line in f.readlines()]:
                        f.write(f"{str(level.number+1)}\n")
                        print(f"written {level.number+1}")

                level_cleared = bold_font3.render("Level cleared!", 1, WHITE)
                score_level_cleared = bold_font2.render(str(score), 1, WHITE)
                if level.number_of_birds >= 0 and not pigs and bonus_score_once:
                    score += (level.number_of_birds) * 10000
                    bonus_score_once = False

                # Centered black background rect
                center_x = screen_width // 2
                center_y = screen_height // 2
                rect_width = 800  # Width: 80% screen or 600px max
                rect_height = screen_height  # Height: full screen or a fixed value like 650px

                rect = pg.Rect(
                    center_x - rect_width // 2,  # Center X
                    center_y - rect_height // 2,  # Center Y
                    rect_width,
                    rect_height
                )
                # Create a semi-transparent surface for the background
                overlay = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                overlay.fill((0, 0, 0, 180))  # Black with alpha for semi-transparency
                screen.blit(overlay, (rect.x, rect.y))
                
                # Draw win image if available
                if win_imgs:
                    win_img_choice = random.choice(win_imgs)
                    win_image_surface = pg.image.load(load_resource(f"./resources/images/win_imgs/{win_img_choice}")).convert_alpha()
                    win_image_scaled = pg.transform.scale(win_image_surface, (rect_width, rect_height)) # Scale to fit overlay
                    screen.blit(win_image_scaled, (rect.x, rect.y))

                screen.blit(level_cleared, scale_pos(500, 90)) # "Level Cleared!" text

                if score >= level.one_star:
                    screen.blit(star1, scale_pos(350, 170))
                if score >= level.two_star:
                    screen.blit(star1, scale_pos(495, 120)) # Changed star2 to star1
                if score >= level.three_star:
                    screen.blit(star1, scale_pos(640, 160)) # Changed star3 to star1

                screen.blit(score_level_cleared, scale_pos(575, 400)) # Display score
                screen.blit(pg.transform.scale(replay_button,(int(replay_button.get_width()*scale_x),int(replay_button.get_height()*scale_y))), scale_pos(555, 480))
                screen.blit(pg.transform.scale(next_button,(int(replay_button.get_width()*scale_x),int(replay_button.get_height()*scale_y))), scale_pos(665, 480))
                screen.blit(pg.transform.scale(menu_button,(int(replay_button.get_width()*scale_x),int(replay_button.get_height()*scale_y))), scale_pos(445, 480))

            elif game_state == 3:
                level_failed = bold_font3.render("Level failed!", 1, WHITE)
                score_level_failed = bold_font2.render(str(score), 1, WHITE)

                # Centered background for fail screen
                center_x = screen_width // 2
                center_y = screen_height // 2
                rect_width = 800  # Width: 80% screen or 600px max
                rect_height = screen_height  # Height: full screen or a fixed value like 650px

                rect = pg.Rect(
                    center_x - rect_width // 2,  # Center X
                    center_y - rect_height // 2,  # Center Y
                    rect_width,
                    rect_height
                )
                # Create a semi-transparent surface for the background
                overlay = pg.Surface((rect_width, rect_height), pg.SRCALPHA)
                overlay.fill((0, 0, 0, 180))  # Black with alpha for semi-transparency
                screen.blit(overlay, (rect.x, rect.y))

                if lose_imgs:
                    lose_img_choice = random.choice(lose_imgs)
                    lose_image_surface = pg.image.load(load_resource(f"./resources/images/lose_imgs/{lose_img_choice}")).convert_alpha()
                    lose_image_scaled = pg.transform.scale(lose_image_surface, (rect_width, rect_height)) # Scale to fit overlay
                    screen.blit(lose_image_scaled, (rect.x, rect.y))
                screen.blit(level_failed, scale_pos(500, 90)) # "Level Cleared!" text

                if score >= level.one_star:
                    screen.blit(star1, scale_pos(350, 170))
                if score >= level.two_star:
                    screen.blit(star1, scale_pos(495, 120)) # Changed star2 to star1
                if score >= level.three_star:
                    screen.blit(star1, scale_pos(640, 160)) # Changed star3 to star1

                screen.blit(score_level_failed, scale_pos(575, 400)) # Display score
                screen.blit(pg.transform.scale(replay_button,(int(replay_button.get_width()*scale_x),int(replay_button.get_height()*scale_y))), scale_pos(555, 480))
                screen.blit(pg.transform.scale(menu_button,(int(replay_button.get_width()*scale_x),int(replay_button.get_height()*scale_y))), scale_pos(445, 480))


            elif game_state == 6:
                def draw_levels():
                    global levels_drawn

                    print("Drawing levels")
                    screen.blit(pg.transform.scale(bg, (screen_width, screen_height)), scale_pos(0, 0))
                        
                    # Base pos & spacing for level icons
                    base_x_icon_draw = 100
                    base_y_icon_draw = 50
                    base_spacing_x_icon_draw = 151
                    base_spacing_y_icon_draw = 160
                    levels_per_row_on_screen = 7

                    # Scale icons to screen size
                    icon_width = int(100 * scale_x)
                    icon_height = int(100 * scale_y)
                    level_icon_scaled = pg.transform.scale(level_icon, (icon_width, icon_height))
                    locked_icon_scaled = pg.transform.scale(locked_level_icon, (icon_width, icon_height))
                    # level_icon_rect is used for centering text, its position is relative to (0,0) here
                    level_icon_text_center_rect = level_icon_scaled.get_rect() 

                    start_level_idx_on_page_draw = current_level_page * LEVELS_PER_PAGE

                    for i_on_page_draw in range(LEVELS_PER_PAGE):
                        level_idx_overall_draw = start_level_idx_on_page_draw + i_on_page_draw
                        if level_idx_overall_draw >= MAX_LEVELS:
                            break 

                        level_number_to_display = level_idx_overall_draw + 1
                        level_method_name = f"build_{level_number_to_display}"

                        # Scaled position for each icon
                        row_draw = i_on_page_draw // levels_per_row_on_screen
                        col_draw = i_on_page_draw % levels_per_row_on_screen
                        
                        icon_base_x_current = base_x_icon_draw + (col_draw * base_spacing_x_icon_draw)
                        icon_base_y_current = base_y_icon_draw + (row_draw * base_spacing_y_icon_draw)
                        icon_screen_x_draw, icon_screen_y_draw = scale_pos(icon_base_x_current, icon_base_y_current)

                        # Locked or unlocked icon
                        if getattr(level, level_method_name, None):
                            with open("cleared_levels.txt","r+") as f:
                                if str(level_number_to_display) in [line.rstrip("\n") for line in f.readlines()]:
                                    icon = level_icon_scaled # Unlocked
                                else:
                                    icon = locked_icon_scaled # Locked
                        else:
                            icon = locked_icon_scaled

                        level_text = str(level_number_to_display)
                        level_font = bold_font3.render(level_text, 1, WHITE)
                        text_rect = level_font.get_rect(center=level_icon_text_center_rect.center)

                        # Draw icon & its number
                        screen.blit(icon, (icon_screen_x_draw, icon_screen_y_draw))
                        if getattr(level, level_method_name, None):
                            with open("cleared_levels.txt","r+") as f:
                                if str(level_number_to_display) in [line.rstrip("\n") for line in f.readlines()]:
                                    screen.blit(level_font, (icon_screen_x_draw + text_rect.x, icon_screen_y_draw + text_rect.y))

                    # Draw Back Arrow to Main Menu
                    screen.blit(pg.transform.scale(back_arrow,(100*scale_x,60*scale_y)), scale_pos(30, 570))

                    # Draw Page Navigation Buttons
                    num_pages = (MAX_LEVELS + LEVELS_PER_PAGE - 1) // LEVELS_PER_PAGE
                    
                    # Previous Page Button
                    if current_level_page > 0:
                        prev_page_button_pos_draw = scale_pos(30, 500) # Base: (30, 500)
                        screen.blit(pg.transform.scale(back_arrow, (100*scale_x, 60*scale_y)), prev_page_button_pos_draw)

                    # Next Page Button
                    if current_level_page < num_pages - 1:
                        next_page_button_pos_draw = scale_pos(1070, 500) # Base: (1070, 500)
                        screen.blit(pg.transform.scale(next_arrow_button, (100*scale_x, 60*scale_y)), next_page_button_pos_draw)

                    # Page Number Text
                    page_text_str = f"Page {current_level_page + 1} / {num_pages}"
                    page_font = bold_font.render(page_text_str, 1, WHITE)
                    page_text_rect = page_font.get_rect(centerx=screen_width / 2) # Centered horizontally
                    page_text_pos_y = scale_pos(0, 510)[1] # Y position based on base 510
                    screen.blit(page_font, (page_text_rect.x, page_text_pos_y))


                    # Menu button scaling/pos (currently commented out from blitting)
                    menu_button_scaled = pg.transform.scale(menu_button,
                        (int(menu_button.get_width() * scale_x),
                        int(menu_button.get_height() * scale_y)))
                    menu_x, menu_y = scale_pos(101, 51)
                    #screen.blit(menu_button_scaled, (menu_x, menu_y))
                    levels_drawn = True

                if not levels_drawn:
                    draw_levels()
                #levels_drawn = True


            # start menu
            elif game_state == 7: # Main Menu
                screen.blit(pg.transform.scale(bg, (screen_width, screen_height)), (0,0)) # Draw background


                # Define rects for button collision detection
                # For this request, exit/settings buttons are visually removed.
                exit_button_base_pos_x, exit_button_base_pos_y = 1070, 535
                exit_button_base_width, exit_button_base_height = 120, 120

                scaled_exit_button_pos_x, scaled_exit_button_pos_y = scale_pos(exit_button_base_pos_x, exit_button_base_pos_y)
                scaled_exit_button_width = exit_button_base_width * scale_x
                scaled_exit_button_height = exit_button_base_height * scale_y

                exit_button_rect = pg.Rect(
                scaled_exit_button_pos_x, scaled_exit_button_pos_y,
                scaled_exit_button_width, scaled_exit_button_height
                )


                # Define positions for visual buttons in main menu
                # Play button will be centered on its existing interactive area.
                settings_button_base_pos_x, settings_button_base_pos_y = 1050, 20 # Top right for settings
                settings_button_base_width, settings_button_base_height = 80, 80 # Smaller settings icon
                scaled_settings_button_pos_x, scaled_settings_button_pos_y = scale_pos(settings_button_base_pos_x, settings_button_base_pos_y)
                scaled_settings_button_width = settings_button_base_width * scale_x
                scaled_settings_button_height = settings_button_base_height * scale_y

                settings_button_rect = pg.Rect(
                scaled_settings_button_pos_x, scaled_settings_button_pos_y,
                scaled_settings_button_width, scaled_settings_button_height
                )

                exit_button_main_menu_base_pos_x, exit_button_main_menu_base_pos_y = 20, 20 # Top left for exit
                exit_button_main_menu_base_width, exit_button_main_menu_base_height = 80, 80 # Smaller exit icon
                scaled_exit_mm_pos_x, scaled_exit_mm_pos_y = scale_pos(exit_button_main_menu_base_pos_x, exit_button_main_menu_base_pos_y)
                scaled_exit_mm_width = exit_button_main_menu_base_width * scale_x
                scaled_exit_mm_height = exit_button_main_menu_base_height * scale_y
                exit_button_main_menu_rect = pg.Rect(
                    scaled_exit_mm_pos_x, scaled_exit_mm_pos_y,
                    scaled_exit_mm_width, scaled_exit_mm_height
                )

                # Click button
                for event in pg.event.get():
                    if event.type == pg.QUIT: # Ensure quit works from main menu
                        running = False
                    elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE: # Ensure Esc works
                        # For main menu, ESC can quit.
                        running = False
                    elif event.type == pg.KEYDOWN and event.key == pg.K_RETURN: # Press Enter to "Play"
                        if sound_on: click_sound.play()
                        game_state = 6 # Go to level select
                        settings_open = False # Close settings if open
                    if event.type == pg.MOUSEBUTTONUP and event.button == 1:
                
                        x_mouse, y_mouse = event.pos # Use event.pos for click coordinates

                        clicked_on_main_ui_button = False

                        if settings_open:
                            # Define the sound button's drawn area for click detection
                            # Settings panel base: (screen_width/2 - 150*scale_x, screen_height/2 - 100*scale_y), size (300*scale_x, 200*scale_y)
                            # Sound button within panel, e.g., centered.
                            panel_center_x = screen_width / 2
                            panel_center_y = screen_height / 2
                            sound_btn_panel_rel_x, sound_btn_panel_rel_y = 0, 0 # Centered in panel
                            sound_btn_base_size_w, sound_btn_base_size_h = 60, 60 # Slightly larger sound button

                            scaled_sound_btn_w = sound_btn_base_size_w * scale_x
                            scaled_sound_btn_h = sound_btn_base_size_h * scale_y

                            # Position of sound button relative to screen, centered in panel
                            sound_btn_screen_x = panel_center_x - scaled_sound_btn_w / 2
                            sound_btn_screen_y = panel_center_y - scaled_sound_btn_h / 2
                            
                            interactive_sound_button_rect = pg.Rect(sound_btn_screen_x, sound_btn_screen_y, scaled_sound_btn_w, scaled_sound_btn_h)

                            if interactive_sound_button_rect.collidepoint(x_mouse, y_mouse):
                                sound_on = not sound_on
                                if sound_on: # Play click even when turning on
                                    click_sound.play()
                                clicked_on_main_ui_button = True # Considers click handled by panel
                        
                        if not clicked_on_main_ui_button: # Only check main buttons if panel click didn't happen
                            # Play button click detection (matches the area where it will be drawn)
                            if (478 * scale_x < x_mouse < 711 * scale_x and 247 * scale_y < y_mouse < 400 * scale_y):
                                if sound_on:
                                    click_sound.play()
                                game_state = 6 # Go to level select
                                current_level_page = 0 # Reset to first page of levels
                                settings_open = False # Close settings if open
                            # Visual Settings Button Area
                            elif settings_button_rect.collidepoint(x_mouse, y_mouse):
                                if sound_on:
                                    click_sound.play()
                                settings_open = not settings_open
                            # Visual Exit Button Area
                            elif exit_button_main_menu_rect.collidepoint(x_mouse, y_mouse):
                                if sound_on:
                                    click_sound.play()
                                running = False # Quit the game
                
                # Removed drawing of static floor lines for game_state 7 as per previous request.
                # The background image provides the visual ground.
                # for line in floor.static_lines: 
                #     ... (drawing logic was here) ...
                #     pv1 = line.a
                #     pv2 = line.b
                #     p1 = to_pygame(pv1)
                #     p2 = to_pygame(pv2)
                #     pg.draw.lines(screen, TRANSP, False, [p1, p2], max(1, int(5*scale_y))) # Added thickness for consistency

                dt = 1.0 / 50.0 / 2.0 # Physics step for menu animations
                # Removed physics step for game_state 7 to improve responsiveness,
                # assuming no physics-based animations are active in the main menu.
                # for x in range(2):
                #     space.step(dt)
                play_prompt_text = bold_font2.render("Click or Press Enter to Play", 1, WHITE)
                prompt_rect = play_prompt_text.get_rect(center=(screen_width / 2, screen_height / 2 + 50 * scale_y))
                screen.blit(play_prompt_text, prompt_rect)

                # Draw the Play button
                # The interactive area is (478, 247) to (711, 400) scaled.
                play_button_center_x = (478 + (711 - 478)/2) * scale_x
                play_button_center_y = (247 + (400 - 247)/2) * scale_y
                screen.blit(play_button_scaled, play_button_scaled.get_rect(center=(play_button_center_x, play_button_center_y)))

                # Draw Settings button
                scaled_settings_icon = pg.transform.scale(settings_button, (int(scaled_settings_button_width), int(scaled_settings_button_height)))
                screen.blit(scaled_settings_icon, (scaled_settings_button_pos_x, scaled_settings_button_pos_y))

                # Draw Exit button
                scaled_exit_icon_mm = pg.transform.scale(exit_button, (int(scaled_exit_mm_width), int(scaled_exit_mm_height)))
                screen.blit(scaled_exit_icon_mm, (scaled_exit_mm_pos_x, scaled_exit_mm_pos_y))


                if settings_open: # Draw settings panel if open
                    # Define base position and dimensions for the settings panel (centered)
                    base_panel_width = 300 
                    base_panel_height = 200
                    base_panel_x = (base_width - base_panel_width) / 2
                    base_panel_y = (base_height - base_panel_height) / 2

                    scaled_panel_x, scaled_panel_y = scale_pos(base_panel_x, base_panel_y)
                    scaled_panel_width_float, scaled_panel_height_float = scale_size(base_panel_width, base_panel_height)

                    # Convert to integers for Surface creation, ensuring they are at least 1x1
                    scaled_panel_width = max(1, int(scaled_panel_width_float))
                    scaled_panel_height = max(1, int(scaled_panel_height_float))

                    settings_panel_surface = pg.Surface((scaled_panel_width, scaled_panel_height), pg.SRCALPHA)
                    settings_panel_surface.fill((50, 50, 50, 200))  # Darker semi-transparent grey
                    screen.blit(settings_panel_surface, (scaled_panel_x, scaled_panel_y))

                    # Sound toggle button within the panel
                    sound_btn_base_size_w, sound_btn_base_size_h = 60, 60
                    scaled_sound_btn_w = sound_btn_base_size_w * scale_x
                    scaled_sound_btn_h = sound_btn_base_size_h * scale_y
                    
                    # Position sound button in the center of the panel
                    sound_btn_panel_x = scaled_panel_x + (scaled_panel_width - scaled_sound_btn_w) / 2
                    sound_btn_panel_y = scaled_panel_y + (scaled_panel_height - scaled_sound_btn_h) / 2

                    if sound_on:
                        sound_toggle_img = pg.transform.scale(sound_button_blue, (int(scaled_sound_btn_w), int(scaled_sound_btn_h)))
                    else:
                        sound_toggle_img = pg.transform.scale(muted_sound_button_blue, (int(scaled_sound_btn_w), int(scaled_sound_btn_h)))
                    screen.blit(sound_toggle_img, (sound_btn_panel_x, sound_btn_panel_y))

            # Common drawing for explosions, should be done after background and game elements
            # but before UI elements if they need to be on top.
            active_explosions.update()
            active_explosions.draw(screen)

            pg.display.flip()
            clock.tick(60)



    pg.quit()
    sys.exit()

main_loop()
