# Exploding Crate Polygon Constants
EXPLODING_CRATE_HP = 200 # Health of the exploding crate
EXPLODING_CRATE_MASS = 20
EXPLODING_CRATE_IMG_PATH = "./resources/images/exploding_crate.png" # Ensure this image exists